/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

class: u3Base for C++ (g++) Linux

Started by Carl Friis-Hansen (c) 2006 (carl.friis-hansen@carl-fh.com).
This software is with GPL (use it as you feel like).

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

This class uses some functions from the Labjack company written for the
original C function library called u3.h and u3.c.

The original functions are really very low level functions and not very
friendly for larger applications. I chose to do it all in C++ as this
makes the overview better and the C++ class objects offers better ways
to document the functionality. In this respect, please see the manual
called u3Base.pdf for more detailed description of each method.
The test.cc application is also a good starting point, but bare in mind
that this application expects a U3-USB with an RB12 termination board
with the following modules mounted:
EIO0..EIO7, output relay, CIO0..CIO3 logic input.
However, you can just remove the buildCommandDIN(..) lines employing
thise hardware modules.

Please find the youngest version at any time on:
  http://carl-fh.net/u3/u3base/src/

Tested on harware:
  U3 Firmware Version 1.170
  U3 Bootloader 0.110
  U3 Hardware 1.200
  Upgraded with:
    LJSelfUpgrade V1.09
    U3firmware_117_08152006.hex
  Driver Version:
    2.560

All original development and test is done on Ubuntu Linux version 6.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Change log:

20060905 - Carl Friis-Hansen
  Added logic table functions and structures to stimulate logic outputs
  according to logic inputs. The stimulation happens at the end of each
  call to checkAllInputs().

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
  Reserved strings related to the U3 hardware:
  -------------------------------------------
  FIO0  Channel  0 on main board r/w/p
  FIO1  Channel  1 on main board r/w/p
  FIO2  Channel  2 on main board r/w/p
  FIO3  Channel  3 on main board r/w/p
  FIO4  Channel  4 on main board r/w/p
  FIO5  Channel  5 on main board r/w/p
  FIO6  Channel  6 on main board r/w/p
  FIO7  Channel  7 on main board r/w/p
  FIOT  Internal temperature sensor on main board r/o/p
  EIO0  Channel  8 on U12 termination board r/w/p
  EIO1  Channel  9 on U12 termination board r/w/p
  EIO2  Channel 10 on U12 termination board r/w/p
  EIO3  Channel 11 on U12 termination board r/w/p
  EIO4  Channel 12 on U12 termination board r/w/p
  EIO5  Channel 13 on U12 termination board r/w/p
  EIO6  Channel 14 on U12 termination board r/w/p
  EIO7  Channel 15 on U12 termination board r/w/p
  CIO0  Channel 16 on U12 termination board (logic only) r/w/p
  CIO1  Channel 17 on U12 termination board (logic only) r/w/p
  CIO2  Channel 18 on U12 termination board (logic only) r/w/p
  CIO3  Channel 19 on U12 termination board (logic only) r/w/p
  FIL0  Analog input channel  0 low value alarm/logic state r/o
  FIL1  Analog input channel  1 low value alarm/logic state r/o
  FIL2  Analog input channel  2 low value alarm/logic state r/o
  FIL3  Analog input channel  3 low value alarm/logic state r/o
  FIL4  Analog input channel  4 low value alarm/logic state r/o
  FIL5  Analog input channel  5 low value alarm/logic state r/o
  FIL6  Analog input channel  6 low value alarm/logic state r/o
  FIL7  Analog input channel  7 low value alarm/logic state r/o
  FILT  Internal temperature    low value alarm/logic state r/o
  EIL0  Analog input channel  8 low value alarm/logic state r/o
  EIL1  Analog input channel  9 low value alarm/logic state r/o
  EIL2  Analog input channel 10 low value alarm/logic state r/o
  EIL3  Analog input channel 11 low value alarm/logic state r/o
  EIL4  Analog input channel 12 low value alarm/logic state r/o
  EIL5  Analog input channel 13 low value alarm/logic state r/o
  EIL6  Analog input channel 14 low value alarm/logic state r/o
  EIL7  Analog input channel 15 low value alarm/logic state r/o
  FIM0  Analog input channel  0 mid value logic state r/o
  FIM1  Analog input channel  1 mid value logic state r/o
  FIM2  Analog input channel  2 mid value logic state r/o
  FIM3  Analog input channel  3 mid value logic state r/o
  FIM4  Analog input channel  4 mid value logic state r/o
  FIM5  Analog input channel  5 mid value logic state r/o
  FIM6  Analog input channel  6 mid value logic state r/o
  FIM7  Analog input channel  7 mid value logic state r/o
  FIMT  Internal temperature    mid value logic state r/o
  EIM0  Analog input channel  8 mid value logic state r/o
  EIM1  Analog input channel  9 mid value logic state r/o
  EIM2  Analog input channel 10 mid value logic state r/o
  EIM3  Analog input channel 11 mid value logic state r/o
  EIM4  Analog input channel 12 mid value logic state r/o
  EIM5  Analog input channel 13 mid value logic state r/o
  EIM6  Analog input channel 14 mid value logic state r/o
  EIM7  Analog input channel 15 mid value logic state r/o
  FIH0  Analog input channel  0 high value alarm/logic state r/o
  FIH1  Analog input channel  1 high value alarm/logic state r/o
  FIH2  Analog input channel  2 high value alarm/logic state r/o
  FIH3  Analog input channel  3 high value alarm/logic state r/o
  FIH4  Analog input channel  4 high value alarm/logic state r/o
  FIH5  Analog input channel  5 high value alarm/logic state r/o
  FIH6  Analog input channel  6 high value alarm/logic state r/o
  FIH7  Analog input channel  7 high value alarm/logic state r/o
  FIHT  Internal temperature    high value alarm/logic state r/o
  EIH0  Analog input channel  8 high value alarm/logic state r/o
  EIH1  Analog input channel  9 high value alarm/logic state r/o
  EIH2  Analog input channel 10 high value alarm/logic state r/o
  EIH3  Analog input channel 11 high value alarm/logic state r/o
  EIH4  Analog input channel 12 high value alarm/logic state r/o
  EIH5  Analog input channel 13 high value alarm/logic state r/o
  EIH6  Analog input channel 14 high value alarm/logic state r/o
  EIH7  Analog input channel 15 high value alarm/logic state r/o
  DAC0  Analog output         0
  DAC1  Analog output         1
  RCT0  Logic output port   (64) to reset counter0 w/o
  RCT1  Logic output port   (65) to reset counter1 w/o
  SSW0  Logical input switch  0 software switch via shared memory
  SSW1  Logical input switch  1 software switch via shared memory
  SSW2  Logical input switch  2 software switch via shared memory
  SSW3  Logical input switch  3 software switch via shared memory
  SSW4  Logical input switch  4 software switch via shared memory
  SSW5  Logical input switch  5 software switch via shared memory
  SSW6  Logical input switch  6 software switch via shared memory
  SSW7  Logical input switch  7 software switch via shared memory
  SSW8  Logical input switch  8 software switch via shared memory
  SSW9  Logical input switch  9 software switch via shared memory

  /p    Can be used to indicate physical position for both analog and logic
  r/o   Read only for logic equations
  w/o   Write only for logic equations
  r/w   Read and write for logic equations if channel is output.
  r/w   Read only for logic equations if channel is input.
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



#ifndef _U3BASE_HH_
#define _U3BASE_HH_

#include <unistd.h>
#include <sys/time.h>
#include <time.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <labjackusb.h>


//
//  The default path to the LabJack U3 (1..n) where first dev will be 1
//
#define U3_DEVICE_PATH  1
//
//  The path/name for the shared memory ID data file
//
#define SHM_FILE_NAME   "u3shmID.txt"
//
//  1=Print errors to terminal - 0=Save last error (retrieve with getLastError())
//
#define PRINT_ERRORS    1


//
//  Structure for storing conversion table for an analog input
//
//  User need this structure in order to define a conversion table
//  for analog inputs.
//
typedef struct STRUCT_ANACON {
  double  vInput;             //  Input value
  double  vOutput;            //  Output value
} structAnaCon;



#define U3DEBUG   0
//  Max length of remark strings
#define U3STRLEN  256
//  Last record index in confTable and relayOut
#define U3IOALEN  23
//  Permission for shared memory
#define PERMS     0666
typedef unsigned char   uint8;
typedef unsigned short  uint16;



//
//  Structure for storing assossiation between "FIOn" and number
//  An array of this strucure is initialized by the u3Base constructor
//
typedef struct STRUCT_FECioTable {
  char    fecios[5];          //  FIO0..FIO7, FIOT, EIO0..EIO7, CIO0..CIO3
  int     fecion;             //  0..19
} structFECioTable;

//
//  Structure for storing state of logic outputs (relays)
//
typedef struct STRUCT_RELAYOUT {
  int     logState;           //  State sent to U3 for logic output
  char    offText[U3STRLEN+1];  //  Any user remarks (like "OFF")
  char    onText[U3STRLEN+1];   //  Any user remarks (like "ON")
  time_t  offDelay;             //  Propagation dalay time hi --> lo
  time_t  onDelay;              //  Propagation dalay time lo --> hi
  time_t  offRemain;            //  Remaining time before hi --> lo trans
  time_t  onRemain;             //  Remaining time before lo --> hi trans
} structRelayOut;

//
//  Structure for storing calibration constants
//
typedef struct U3_CALIBRATION_INFORMATION{
  double ainSESlope;
  double ainSEOffset;
  double ainDiffSlope;
  double ainDiffOffset;
  double dacSlope[2];
  double dacOffset[2];
  double tempSlope;
  double tempSlopeLow;
  double calTemp;
  double vref;
  double vref15;
  double vreg;
  double ain0HvSlope;
  double ain1HvSlope;
  double ain2HvSlope;
  double ain3HvSlope;
  double ain0HvOffset;
  double ain1HvOffset;
  double ain2HvOffset;
  double ain3HvOffset;
} u3CalibrationInfo;

//
//  Structure for retrieving all inputs and end calibration etc. of these
//
typedef struct STRUCT_CONFTABLE {
  char    typeAD;             //  'A'=Analog, 'D'=Logic, 'C'=Counter
  int     rBuffPos;           //  9..255
  char    u3Pos[5];           //  FIO0..FIO7, FIOT, EIO0..EIO7, CIO0..CIO3
  int     negCh;              //  Negative channel (default 31)
  int     logState;           //  State received from U3 logic input or alarm state for analog (-1,0,1)
  unsigned long    counter;   //  Counter value 0..(256*256*256*256-1) or in other words 32bit
  unsigned long    cntLimit;  //  When counter >= cntLimit sets logState to 1
  double  voltage;            //  Voltage received from U3 via binaryToCalibratedAnalogVoltage(...)
  double  calibrat;           //  1.0 standard 2.44V multiplication factor (Analog only)
  double  limitLow;           //  low voltage limit (Analog only) sets loState to -1
  double  limitHigh;          //  high voltage limit (Analog only) sets logState to 1
  double  hysteresis;         //  Voltage hysteresis for logState change (default 0.0)
  char    remarks[U3STRLEN+1];//  Any user remarks
  structAnaCon  *anaCon;      //  Pointer to conversion table (NILL) if not initiated
  int     anaConLen;          //  size of convertion table
  time_t  offDelay;           //  Propagation dalay time hi --> lo
  time_t  onDelay;            //  Propagation dalay time lo --> hi
  time_t  offRemain;          //  Remaining time before hi --> lo trans
  time_t  onRemain;           //  Remaining time before lo --> hi trans
} structConfTable;

//
//  Structure for storing logic table for logic analog input and logic digital input
//
typedef struct STRUCT_LOGTAB {
  char    lOutput[6];         //  Logic digital output (relay)
  char    lInput[1024];       //  Logic digital input and analog Low/Mid/High limit
} structLogTab;

typedef struct STRUCT_STREAMINFO {
  int     numChannels;
  int     samplesPerPacket;
  int     scanInterval;
} stuctStreamInfo;

typedef struct share_mem    //  This structure can hold all input/output in shared memory
{
  int             newDataAvailable;       //  Parent sets this to 1 and any monitor can set it to 0
  structConfTable confTable[U3IOALEN+1];  //  Varibale to hold retrieved with u3Base::getConfTable(...)
  structRelayOut  relayOut[U3IOALEN+1];   //  Variable to hold Logic output (relay) state
  int             ssw[10];                //  10 logic input software switches for boolean equations
} structSharemem;



class u3Base
{
  protected:
    char              lastError[255];
    structConfTable   confTable[U3IOALEN+1];
    int               confTabEnd;
    structFECioTable  FECioTable[36];
    structRelayOut    relayOut[U3IOALEN+1];
    u3CalibrationInfo caliInfo;
    structLogTab      logTab[U3IOALEN+1];
    int               logTabEnd;
    stuctStreamInfo   streamInfo;
    uint8             sendBuff[255],  sendBuff2[255]; //  Buffer for bytes to be sent to u3  
    uint8             recBuff[255],   recBuff2[255];  //  Buffer for bytes received from u3
    ULONG             sendLength,     sendLength2;    //  Number of bytes to send to u3
    ULONG             recLength,      recLength2;     //  Number of bytes to receive from u3
    HANDLE            fd;                             //  u3 device ID/handle
    char              sBinRet[65];                    //  For return of binary as string
    char              cnt0[5];                        //  Counter0 channel name
    char              cnt1[5];                        //  Counter1 channel name
    int               logicChange;                    //  A lgic change has occurred since last checkAllInputs()
    int               ssw[10];                        //  Series of software switches to interact in Boolean equations.
    char              versionInfo;                    //  Version info obtained from wrConfig return byte index 37
    char              hvVersion;                      //  Is true if this is U3C High Voltage version

    //
    //  Specially for shared memory
    //
    int               shmid;          //  Id of shmem to pass on to child program
    structSharemem    *shareptr;      //  Pointer to the shared memory assigned by shmget(...)
    FILE              *shmIDFile;     //  File data is the ID of the shared memory
    char              charTemp[255];



  public:
    //  -------- Setup section --------

                        //  Constructor
            u3Base(     int devicePath );   //  First U3 device has number 1.

                        //  Destructor
    virtual ~u3Base(    void );

                        //  Verification of connection to hardware
    HANDLE  getConnecID(void );             //  returns NULL on connection error during construction

                        //  Write values to current state only. This is the most reliable way.
    int     writeConf(  const char *FIOAnalog,      //  "11111111" 1=Analog 0=logic/digital
                        const char *EIOAnalog,      //  "00000000" 1=Analog 0=logic/digital
                        const char *DirFIO,         //  "00000000" 1=out 0=in (for logic/digital only)
                        const char *DirEIO,         //  "00000111" 1=out 0=in (for logic/digital only)
                        const char *DirCIO,         //      "0011" 1=out 0=in
                        const char *cntIO0,         //  ""=no counter0 else "FIO0".."EIO7"
                        const char *cntIO1 );       //  ""=no counter1 else "FIO0".."EIO7"

                        //  Write default startup values to flash (EEPROM). Not working for stateCIO!
    int     writeConf(  const char *FIOAnalog,      //  "11111111" 1=Analog 0=logic/digital
                        const char *EIOAnalog,      //  "00000000" 1=Analog 0=logic/digital
                        const char *DirFIO,         //  "00000000" 1=out 0=in (for logic/digital only)
                        const char *DirEIO,         //  "00000111" 1=out 0=in (for logic/digital only)
                        const char *DirCIO,         //  "00000011" 1=out 0=in
                        const char *stateFIO,       //  "00000000" 1=hi/on 0=lo/off
                        const char *stateEIO,       //  "00000000" 1=hi/on 0=lo/off
                        const char *stateCIO,       //      "0000" 1=hi/on 0=lo/off
                        const char *cntIO0,         //  ""=no counter0 else "FIO0".."EIO7"
                        const char *cntIO1 );       //  ""=no counter1 else "FIO0".."EIO7"

                        //  Starting point for building the functionality.
                        //  The whole buildCommand..... section must be completed before
                        //  any call is done to the main loop function checkAllInputs().
    void    buildInputCommandStart( void );

                        //  Command and configure an analog channel.
                        //  Only one buildInputCommandAIN(...) per analog channel.
                        //  If neg channel=SE/31 then you can use the next function instead.
                        //  The limitLow and limitHigh are set points of output at which a
                        //  logic state is recognized and can be used by means of logicTableAdd(...)
                        //  to set state of logic outputs.
    int     buildInputCommandAIN( const char  *sFECio,    //  FIO0..7, FIOT, EIO0..7
                                  int         nch,        //  If neg channel
                                  double      calibrat,   //  deviation from 2.44V (default 1.0)
                                  double      limitLow,   //  Value where "FILx" or "EILx" becomes hi
                                  double      limitHigh,  //  Value where "FIHx" or "EIHx" becomes hi
                                  const char  *remarks    //  Limited to 256 characters
                                );

                        //  Command and configure an analog channel.
                        //  Only one buildInputCommandAIN(...) per analog channel.
                        //  The limitLow and limitHigh are set points of output at which a
                        //  logic state is recognized and can be used by means of logicTableAdd(...)
                        //  to set state of logic outputs.
    int     buildInputCommandAIN( const char  *sFECio,    //  FIO0..7, FIOT, EIO0..7
                                  double      calibrat,   //  deviation from 2.44V (default 1.0)
                                  double      limitLow,   //  Value where "FILx" or "EILx" becomes hi
                                  double      limitHigh,  //  Value where "FIHx" or "EIHx" becomes hi
                                  const char  *remarks    //  Limited to 256 characters
                                );

                        //  Command and configure a logic/digital channel.
                        //  Only one buildInputCommandDIN(...) per logic channel.
    int     buildInputCommandDIN( const char  *sFECio,    //  FIO0..7, EIO0..7, CIO0..3
                                  const char  *remarks    //  Limited to 256 characters
                                );

                        //  Command and configure a counter channel.
                        //  Only one buildInputCommandCIN(...) per counter channel.
    int     buildInputCommandCIN( const char  *sFECio,    //  FIO0..7, EIO0..1
                                  int         cntNum,     //  0=counter0 1=counter1
                                  unsigned long cntLimit, //  Set logState at this point
                                  const char  *remarks    //  Limited to 256 characters
                                );

                        //  Call this to conclude and activate the command sets.
    void    buildInputCommandEnd( void );             //  Must conclude the build commands

                        //  Command to include a user conversion table.
                        //  The table will do conversion on final calibrated output value and
                        //  before any call to logicTable or other function that might depend
                        //  on the analog output value.
    int     buildInputCommandANC( const char  *sFECio,    //  FIO0..7, FIOT, EIO0..7
                                  structAnaCon  *anaCon,  //  Conversion table
                                  int         anaConLen   //  Size of table (number of entries)
                                );

                        //  Command to implement hysteresis in connection with change og logic
                        //  state between limitLow to mid range and limitHight to mid range.
                        //  The hysteresis is an absolute value proportional to the output.
    int     buildInputCommandHYS( const char  *sFECio,    //  FIO0..7, FIOT, EIO0..7
                                  double      hysteresis  //  Hysteresis for changing logState
                                );

                        //  Set the time in seconds it take for an input to go from
                        //  hi-->lo and from lo-->hi or if analog hi/lo-->mid and mid-->hi/lo
                        //  This is not applicable to Counter Inputs
    void    buildInputCommandDelay(const char *sFECio,      //  FIO0..7, EIO0..7, CIO0..3
                                  time_t      offDelay,     //  Propagation delay time in seconds (or off alarm)
                                  time_t      onDelay );    //  Propagation delay time in seconds (or to alarm)

                        //  Use this function to automatically set/reset logic outputs each time
                        //  checkAllInputs() is called. Only one call per output or output hazard
                        //  would occur (there is a build in check for this though).
                        //  The condition/equation string sFECi must be less that 1024 characters and
                        //  have at leas one parameter.
                        //  The evaluation of sFECi is done with '*' operators first and '+' operators last
                        //  unless '(' and ')' are used. All parameters MUST be separated by one space ' '
                        //  like: logicTableAdd("CIO1","( !EIO6 + FIL5 ) * FIO3")
    int     logicTableAdd(  const char    *sFECo,     //  FIO0..7, EIO0..7, CIO0..3 (Logic digital output)
                                                      //  RCT0..1
                            const char    *sFECi);    //  FIL0..7, FILT, EIL0..7,   (logic analog Low input)
                                                      //  FIM0..7, FIMT, EIM0..7,   (logic analog Mid input)
                                                      //  FIH0..7, FIHT, EIH0..7,   (logic analog High input)
                                                      //  FIO0..7, EIO0..7, CIO0..7,(logic digital input/output)
                                                      //  *, +, (, ), !             (logic operators)

                        //  Associate a text with the hi and lo state of a logic output
                        //  After checkAllInputs() the current state can be read as text with
                        //  the method getRealayText(...)
    void    setRelayText(   const char  *sFECio,      //  FIO0..7, EIO0..7, CIO0..3
                            const char  *offText,     //  Like: "The relay is OFF"
                            const char  *onText );    //  Like: "The relay is ON"

                        //  Set the time in seconds it take for a logic output to go from
                        //  hi-->lo and from lo-->hi
    void    setRelayDelay(  const char  *sFECio,      //  FIO0..7, EIO0..7, CIO0..3
                            time_t      offDelay,     //  Propagation delay time in seconds
                            time_t      onDelay );    //  Propagation delay time in seconds

                        //  This function sets up a command in the U3 device to acquire fast reads.
                        //  At this time the streaming functions are not completely implemented and
                        //  should therefore not be used!
    int     streamConfig(         int numChannels,        //  
                                  int samplesPerPacket,   //  1..16
                                  int scanInterval );     //  1..65535

                        //  After a call to this method, other programs can read incoming data via shred
                        //  memory. The ID of the shared memory is written to a file named SHM_FILE_NAME.
                        //  The data in shared memory is structured according to the structSharemem struct.
                        //  It is up to the connecting program to attach to the shared memory and to
                        //  remember to deattach from it again before exit.
    int     useSharedMemory(void );                       //  Method returns 0 if OK and -1 on error.

    //  -------- Run section --------

                        //  Each time checkAllInputs() is called the inputs, defined with the
                        //  buildInputCommand... methods, are read from the U3 device, evaluated
                        //  and acted upon. The new data are available through various methods
                        //  described below.
    int     checkAllInputs( void );

                        //  Number of items in confTable. The items were defined with buildInputCommand..
                        //  The function is useful in connection with retrieve loops like:
                        //  for(n=0;n<u3Base::getNumConfTable();n++) printf("%d=%c\n",n,u3Base::getInputType(n));
    int     getNumConfTable( void );

                        //  As all data are received they are put into a structured array in
                        //  sequence.
                        //  You can retrieve the type of channel that corresponds to this sequence number.
    char    getInputType(   int inputNumber );

                        //  As all data are received they are put into a structured array in
                        //  sequence.
                        //  You can retrieve the channel name that corresponds to this sequence number.
    const char*   getInputFECio(  int inputNumber );

                        //  Get actual logic state as text set by setRelayText(...)
    const char*   getRelayText(   const char  *sFECio );    //  FIO0..7, EIO0..7, CIO0..3 Logic text

                        //  Get actual logic state
    int     getRelayState(  const char  *sFECio );    //  FIO0..7, EIO0..7, CIO0..3 Logic output

                        //  Get actual logic state
    int     getInputState(  int         inputNumber );//  0..getNumConfTable()-1    Logic input

                        //  Get actual logic state
    int     getInputState(  const char  *sFECio );    //  FIO0..7, EIO0..7, CIO0..3 Logic input

                        //  Get sotfware input switch state
    int     getSSW(         const char  *sFECio );    //  SSW0..9

                        //  Get actual value of analog input
    double  getInputVoltage(int         inputNumber );//  0..getNumConfTable()-1    Analog input

                        //  Get actual value of analog input
    double  getInputVoltage(const char  *sFECio );    //  FIO0..7, FIOT, EIO0..7    Analog input

                        //  Get value of counter
    long    getInputCount(  int         inputNumber );//  0..getNumConfTable()-1   Counter input

                        //  Get value of counter
    long    getInputCount(  const char  *sFECio );    //  FIO0..7, EIO0..1         Counter input

                        //  Get text associated with analog input
    const char*   getInputText(   int         inputNumber );//  0..getNumConfTable()-1          Input

                        //  Get text associated with analog input
    const char*   getInputText(   const char  *sFECio );    //  FIO0..7, FIOT, EIO0..7, CIO0..3 Input

                        //  Get all info for an input in a structConfTable variable
    int     getConfTable(   int         inputNumber,  //  0..getNumConfTable()-1
                            structConfTable *table ); //  User variable to retrieve the lot

                        //  Get all info for an input in a structConfTable variable
    int     getConfTable(   const char  *sFECio,      //  FIO0..7, FIOT, EIO0..7, CIO0..3
                            structConfTable *table ); //  User variable to retrieve the lot

                        //  Get all info for an output in a structRelayOut variable
    int     getRelayOut(    int         outputNumber, //  0..U3IOALEN
                            structRelayOut *table );  //  User variable to retrieve the lot

                        //  Get all info for an output in a structRelayOut variable
    int     getRelayOut(    const char  *sFECio,      //  FIO0..7, FIOT, EIO0..7, CIO0..3
                            structRelayOut *table );  //  User variable to retrieve the lot

                        //  Convert from channel name to channel number
    int     FECioToNum(     const char  *sFECio );    //  FIO0..7, FIOT, EIO0..7, CIO0..3 ==> 0..19

                        //  Set logic output to hi (1) or lo (0)
    int     setRelay(       int         outputNumber, //  Channel 0..19
                            int         state );      //  0=Off, 1=On

                        //  Set logic output to hi (1) or lo (0)
    int     setRelay(       const char  *sFECio,      //  Channel FIO0..7, EIO0..7, CIO0..3
                            int         state );      //  0=Off, 1=On

                        //  Set any number of logic outputs to hi (1) or lo (0)
    int     setRelayComplex(const char  *action );    //  Channel FIO0..7, EIO0..7, CIO0..3
                                                      //  Many actions separated with space (' ').
                                                      //  Use '!' in front of channel name to reset instead of set.

                        //  Set/Reset sotfware input switch
                        //  The initial state is !SSWn or in other words: off/lo/0
    int     setSSW(         const char  *sFECio );    //  SSW0..9 (hi), !SSW0..9 (lo)

                        //  Reset counter0 or counter1
    int     resetCounter(   int         cntNum );     //  0=counter0 1=counter1

                        //  Set green LED on main board on (1) or off (0)
    int     setLED(         int         state );      //  LED on: state=1 off: state=0

                        //  Activate the internal buzzer on main board (not fully tested)
    int     buzz(           void );                   //  for 500msec @ 4KHz

                        //  Set the voltage of analog of DAC0 or DAC1
    int     setDAC(         const char  *sDAC,        //  Channel DAC0..1
                            double      value );      //  0..2.44V

                        //  At this time the streaming functions are not completely implemented and
                        //  should therefore not be used!
    int     streamStart(    void );                   //  Start streaming (must be set with streamConfig(...) )

                        //  At this time the streaming functions are not completely implemented and
                        //  should therefore not be used!
    int     streamStop(     void );                   //  Start streaming (must be started with streamStart() )

                        //  At this time the streaming functions are not completely implemented and
                        //  should therefore not be used!
    int     streamData(     void );                   //  Start streaming (must be started with streamStart() )

                        //  Returns 1 (true) if an input has changed logic state since last call
                        //  to getLogicChange().
    int     getLogicChange();

                        //  Return last error text.
                        //  Use this if a method returns -1
    const char*   getLastError( void );

    //  -------- General public utility functions --------

    int     binToInt(const  char        *s );         //  Convert text based binary to int ("0101"=>5)
    const char*   intToBin(       int         i,            //  Convert int to text based binary (5=>"00000101")
                            int         isWord );     //  0: 8bit, 1: 16bit


    //  -------- Some development public utility functions --------

    void    printU3configuration( void );             //  Prints the sendBuff contents thus describing configuration
    void    printSendBuff2( int         nmax );       //  For test only
    const char*   getErrorText(   int         code );       //  Convert error code to error text.


    //  -------- Internal section --------

  protected:
    long    getCalibrationInfo( void );

    int     sendCommandU3(      uint8* sendBuf, ULONG sendLen );
    int     recCommandU3(       uint8* recBuf,  ULONG recLen );

    void    normalChecksum(     uint8 *b, int n );
    void    extendedChecksum(   uint8 *b, int n );
    uint8   normalChecksum8(    uint8 *b, int n );
    uint16  extendedChecksum16( uint8 *b, int n );
    uint8   extendedChecksum8(  uint8 *b );

    HANDLE  openUSBConnection(  int pathname );
    int     closeUSBConnection( void );

    double  FPuint8ArrayToFPDouble(uint8 *buffer, int startIndex);

    long    binaryToCalibratedAnalogVoltage( int negChannel, uint16 bytesVoltage, double *analogVoltage );
    long    binaryToCalibratedAnalogHvVoltage( int channelNumber, uint16 bytesVoltage, double *analogVoltage );
    long    binaryToCalibratedAnalogTemperature( uint16 bytesTemperature, double *analogTemperature );
    long    analogToCalibratedBinaryVoltage( int channelNumber, double analogVoltage, uint8 *bytesVoltage );
    long    binaryToUncalibratedAnalogVoltage( int negChannel, uint16 bytesVoltage, double *analogVoltage );
    long    analogToUncalibratedBinaryVoltage( double analogVoltage, uint8 *bytesVoltage );

    int     getConfTableNum( const char *sFECio );

    double  vOutputAnaCon(  int     inputNumber,  //  Index in confTable
                            double  vInput );     //  Input value from an analog u3 channel

    int     setDAC(         int     dacNumber,    //  0..1
                            int     value );      //  0..255

    int     logTableCheck(void );
    int     logicTableEval( int nLogTab );
    int     logEval( char *sEval );

    //  -------- Methods intended for overloading by class extensions --------

    virtual int     analogFilter( int confTableIndex );   //  u3Base::confTable[confTableIndex].voltage
                                                  //  holds the newly retrieved value to be filetered
                                                  //  Actions on value is first taken after this filter.
                                                  //  In u3Base this method doesn't affect the value.

};  //  class u3Base



#endif
