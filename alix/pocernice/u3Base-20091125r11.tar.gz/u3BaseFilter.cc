/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

        D E M O   C L A S S    

 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



#include  "u3Base.hh"
#include  "u3BaseFilter.hh"



u3BaseFilter::u3BaseFilter( int devicePath ) : u3Base( devicePath )
{
  int n;

  //
  //  Clear flag table for analog filter
  //
  for( n=0; n<U3IOALEN; n++ ) {
    vOldFirst[n]  = 1;
    timeConst[n]  = 0; //  Default 0 (disabled) 1200 to 1min @ 20msec sample rate
  }
} //  u3BaseFilter::u3BaseFilter(...)



u3BaseFilter::~u3BaseFilter( void )
{
  //~u3Base();
  //~u3BaseFilter();
} //  u3BaseFilter::~u3BaseFilter()



int     u3BaseFilter::analogFilter( int confTableIndex )
{
  if( timeConst[confTableIndex] > 0 ) {
    //
    //  u3Base::confTable[confTableIndex].voltage holds the newly retrieved value to be filetered
    //
    if( vOldFirst[confTableIndex] ) {
      //
      //  First sample, so filtering not possible before next sample
      //
      vOldFirst[confTableIndex] = 0;
    } else {
      //
      //  22 samples to reach 90%. Sample rate usually 20msec, thus 1200 gives a time constant of 1min.
      //
      confTable[confTableIndex].voltage =
        (confTable[confTableIndex].voltage-vOld[confTableIndex])/timeConst[confTableIndex]+vOld[confTableIndex];
    }
    //
    //  Preserve the filtered value until next sample
    //
    vOld[confTableIndex] = confTable[confTableIndex].voltage;
  }
  return  0;
} //  u3BaseFilter::analogFilter(...)



int   u3BaseFilter::setTimeConst( const char  *sFECio,    //  FIO0..7, FIOT, EIO0..7
                                  int         timeConst ) //  0...any positive value
{
  int n;

  if( timeConst >= 0 ) { //  Check for positive time constant;
    for( n=0; strcmp(getInputFECio(n),sFECio) != 0 && n<U3IOALEN; n++ ); //  Get input number
    if( n < U3IOALEN && confTable[n].typeAD == 'A' ) {  //  Check if sFECio found and is analog
      this->timeConst[n] = timeConst; //  Apply new time constant value
      return  0;
    } else {
      printf( "Error u3BaseFilter::setTimeConst: sFECio invalid (%s)\n", sFECio );
      return -1;
    }  
  } else {
    printf( "Error u3BaseFilter::setTimeConst: timeConst out of range (%s, %d)\n", sFECio, timeConst );
    return -1;
  }
} //  u3BaseFilter::setTimeConst(...)
