/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

        D E M O   P R O G R A M

monitor data in shared memory provided by "./ljrun --config" using u3Base class

Started by Carl Friis-Hansen 2006 (carl.friis-hansen@carl-fh.com).
This software is with GPL (use it as you feel like).

This program "./monitor" should only be called after "./ljrun --config" is up
and running. See the u3Base manual regarding the use of shared memory and
secondary programs.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

In order to run it, you will need the program "./ljrun --config" to run.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

The program data2db (php) sends data from U3 and WX200, provided here, to
the database table 'climate'.
The program index2 (php) creates a graph from the data provided in template
file and database table 'climate'.

 CREATE TABLE `c1carl`.`climate` (
`recid` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
`date` DATE NOT NULL ,
`time` TIME NOT NULL ,
`temp` DOUBLE( 5, 1 ) NOT NULL DEFAULT '0.0',
`baro` DOUBLE( 4, 0 ) NOT NULL DEFAULT '1000',
`rain` DOUBLE( 4, 0 ) NOT NULL DEFAULT '0',
`wind` DOUBLE( 4, 0 ) NOT NULL DEFAULT '0',
`direc` DOUBLE( 4, 0 ) NOT NULL DEFAULT '0',
`light` DOUBLE( 4, 0 ) NOT NULL DEFAULT '0',
PRIMARY KEY ( `recid` )
) TYPE = MYISAM COMMENT = 'Storing of weather data from U3 and WX200' 

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


//
//  ================ Includes ================
//

#include  <sys/shm.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  "u3Base.hh"
#include  "saveterm.hh"





//
//  ================ Forward declarations ================
//

void  printHelpMessage( char *argv );
void  makeGraph(
          char    *sInterfilename,      //  "val_temp2.cdf",
          char    *sImageName,          //  Name of PNG image file
          int     iWidth,               //  640,
          int     iHeight,              //  320,
          char    *sTitle,              //
          char    *sAxisTextX,          //  "History in Hours",
          char    *sAxisTextY,          //  "Temperature in Celsius",
          double  iYdivision,           //  0.5,
          double  *adYdata,             //  24.6, -12.2, etc.
          double  dYmax,                //  16,
          double  dYmin                 //  -24
      );



//
//  ================ Application manin ================
//

int   main( int argc, char **argv )
{
  //long  count;
  div_t dcount;
  //
  //  Specially for shared memory
  //
  int               shmid;          //  Id of shmem to pass on to child program
  structSharemem    *shareptr;      //  Pointer to the shared memory assigned by shmget(...)
  FILE              *shmIDFile;     //  File data is the ID of the shared memory
  char              charTemp[255];

  //  ---- For acc of CEIO2 ----
  int     logStateCIO2  = 0;
  time_t  timeStampCIO2 = 0;
  time_t  timeAccCIO2   = 0;
  int     printItCIO2   = 0;

  //  ---- For outerloop ----
  int     kchar     = 0;
  int     n;

  //  ---- For inner loop ----
  time_t  tim;
  tm      *now;


  //
  //  Now to the program seequence
  //
  if( argc > 1 && strcmp( argv[1], "--help" ) == 0 ) {
    printHelpMessage( argv[0] );
    return  1;
  }

  if( ( shmIDFile = fopen( SHM_FILE_NAME, "r" ) ) != NULL ) { //  SHM_FILE_NAME is defined in u3Base.hh
    fgets( charTemp, 16, shmIDFile );
    fclose( shmIDFile );
    shmid = atoi( charTemp );
    //
    //  Using shmat(...) to attach to shared memory
    //
    if( (shareptr = (structSharemem *) shmat( shmid, 0, 0) ) == (structSharemem *) -1 ) {
      perror("can't attach to shared memory\n");
    }
    printf( "Using shared memory %d\n", shmid );
  } else {
    shmid = 0;
    printf( "Error opening file %s in order to acquire shared memory ID\n", SHM_FILE_NAME );
  }

  saveterm st;  //  Construct class to save current terminal and implement kbhit() method
                //  The destructor takes care of restoring the original terminal values.

  //
  //  Show initial state of the first four software switches
  //
  if( shmid > 0 ) {
    for( n = 0; n < 4; n++ ) {
      printf( "SSW%d: %d\n", n, shareptr->ssw[n] );
    }
  }


  //
  //  Start the wx200 daemon on first serial port
  //
  if( system( "wx200d -r -s /dev/ttyS0" ) != 0 ) {
    perror("Failed command 'wx200d -r -s /dev/ttyS0'\n");
  }



  printf( "Press 'q'=quit, 's'=status and '0'..'4'=!SSW0..!SSW4\n" );
  printf( "----------------------------------------------------\n" );

  while( ( kchar = st.kbhit() ) != 'q' && shmid > 0 )
  {
    tim=time(NULL);
    dcount = div( tim, 3600 );  //  Every hour (60 * 60sec)
    if( dcount.rem == 0 || kchar == 't' ) { //  Only print every 20 min or if 't' is pressed
      now=localtime(&tim);

      //
      //  ---- Store new data in database climate@c1carl@carl-fh.net ----
      //
      if( system( "wx200 --kph --tab | ./data2db" ) != 0 ) {
        perror("Failed command 'wx200 --kph --tab | ./data2db'\n");
      }
      
      //
      //  ---- Make new week graphs and new month graphs ----
      //
      if( system( "./data2db --week" ) != 0 ) {
        perror("Failed command './data2db --week'\n");
      }
      if( system( "./data2db --month" ) != 0 ) {
        perror("Failed command './data2db --month'\n");
      }
      if( system( "./data2db --month3" ) != 0 ) {
        perror("Failed command './data2db --month3'\n");
      }

      //  ---- FTP all releveant files to web server using shell script ----
      if( system( "./temp2website" ) != 0 ) {
        perror("Failed command './temp2website' to FTP 'temp2.txt' to '192.168.0.34'\n");
      }
      sleep(1);
    } //  if( dcount.rem == 0 || kchar == 't' )

    //
    //  Accumulations
    //
    if( logStateCIO2 != shareptr->confTable[7].logState ) {
      //  Act only if logic state has changed
      if( timeStampCIO2 == 0 ) {
        //  No valid previous current time (start process)
        timeStampCIO2 = time( NULL );
        printItCIO2   = 0;
      } else {
        //  A valid previous current time exists
        if( shareptr->confTable[7].logState == 0 ) {
          //  Logic state has changed from true to false
          timeAccCIO2 = time( NULL ) - timeStampCIO2;  //  Sum time difference from start process
          printItCIO2 = 1;
        } else {
          //  Logic state has changed from false to true
          timeStampCIO2 = time( NULL );
          printItCIO2   = 0;
        }
      }
      logStateCIO2 = shareptr->confTable[7].logState; //  Accept new logic state
      if( printItCIO2 == 1 ) {
        printf( "Oil burner total period %dsec\n", (int) timeAccCIO2 );
      }
    }
    if( kchar == '0' ) { //  Toggle SSW0
      shareptr->ssw[0] = !shareptr->ssw[0];
      printf( "SSW0 (Emergency power): %d\n", (int) shareptr->ssw[0] );
    }
    if( kchar == '1' ) { //  Toggle SSW1
      shareptr->ssw[1] = !shareptr->ssw[1];
      printf( "SSW1 (Battery test): %d\n", (int) shareptr->ssw[1] );
    }
    if( kchar == '2' ) { //  Toggle SSW2
      shareptr->ssw[2] = !shareptr->ssw[2];
      printf( "SSW2 (oil burner enable): %d\n", (int) shareptr->ssw[2] );
    }
    if( kchar == '3' ) { //  Toggle SSW3
      shareptr->ssw[3] = !shareptr->ssw[3];
      printf( "SSW3 (Heater): %d\n", (int) shareptr->ssw[3] );
    }
    if( kchar == '4' ) { //  Toggle SSW4
      shareptr->ssw[4] = !shareptr->ssw[4];
      printf( "SSW4 (oil burner start override): %d\n", (int) shareptr->ssw[4] );
    }
    if( kchar == 's' ) { //  Status display
      printf( "SSW0 (Emergency power)          : %d\n", (int) shareptr->ssw[0] );
      printf( "SSW1 (Battery test)             : %d\n", (int) shareptr->ssw[1] );
      printf( "SSW2 (oil burner enable)        : %d\n", (int) shareptr->ssw[2] );
      printf( "SSW3 (Heater)                   : %d\n", (int) shareptr->ssw[3] );
      printf( "SSW4 (oil burner start override): %d\n", (int) shareptr->ssw[4] );
    }
    //
    //  20msec sleep
    //
    usleep( 20 * 1000 ); //  1/50 sec
  } //  while(...) loop

  printf( "\n" );


  //
  //  Remember to detach from shared memory using shmdt(...)
  //
  if( shmid > 0 && shmdt( shareptr ) < 0 ) {
    perror("child failed to detach from shared memory :-(\n");
  }

  return 0;
} //  main(...)



//
//  ================ Sub functions ================
//

void    printHelpMessage( char *argv )
{
    printf( "\n" \
            "Interface to interface to Labjack U3-USB for Linux\n" \
            "By Carl Friis-Hansen GPL 2006 - http://carl-fh.net/u3/\n" \
            "This is an independent monitor program assuming ./test is\n" \
            "running.\n" \
            "\n" \
            "Usage:\n" \
            "  %s\n" \
            "  %s --help                       (this help message)\n" \
            "\n" \
            "Return codes:\n" \
            "  0: Normal termination\n" \
            "  1: --help option given or error\n" \
            "\n" \
            ,argv ,argv );
} //  printHelpMessage(...)

