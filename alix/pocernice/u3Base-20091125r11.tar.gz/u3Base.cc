/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

class: u3Base for C++ (g++) Linux

SVN: http://repro.carl-fh.com/subv/u3base

Started by Carl Friis-Hansen (c) 2006 (carl.friis-hansen@carl-fh.com).
This software is with GPL (use it as you feel like).

Major change November 2009 in order to satisfy new USB driver from 
LabJack.
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

This class uses some functions from the Labjack company written for the
original C function library called u3.h and u3.c.

The original functions are really very low level functions and not very
friendly for larger applications. I chose to do it all in C++ as this
makes the overview better and the C++ class objects offers better ways
to document the functionality. In this respect, please see the manual
called u3Base.pdf for more detailed description of each method.
The test.cc application is also a good starting point, but bare in mind
that this application expects a U3-USB with an RB12 termination board
with the following modules mounted:
EIO0..EIO7 output relay, CIO0..CIO3 logic input.
However, you can just remove the buildCommandDIN(..) lines employing
thise hardware modules.

Please find the youngest version at any time on:
  http://carl-fh.net/u3/u3base/src/

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



#include  <sys/shm.h>
#include  "u3Base.hh"

const char*   u3Base::getErrorText( int code )
{
  typedef struct STRUCT_ERRORTEXT {
    int     code;           //  Error number as returned by the U3 device
    char    text[64+1];     //  The corresponding text as described in LabJacks pdf document
  } structErrorText;

  static structErrorText errorText[] = {
    {0,  "SUCCESS"},
    {1,  "SCRATCH_WRT_FAIL"},
    {2,  "SCRATCH_ERASE_FAIL"},
    {3,  "DATA_BUFFER_OVERFLOW"},
    {4,  "ADC0_BUFFER_OVERFLOW"},
    {5,  "FUNCTION_INVALID"},
    {6,  "SWDT_TIME_INVALID"},
    {7,  "XBR_CONFIG_ERROR"},
    {16, "FLASH_WRITE_FAIL"},
    {17, "FLASH_ERASE_FAIL"},
    {18, "FLASH_JMP_FAIL"},
    {19, "FLASH_PSP_TIMEOUT"},
    {20, "FLASH_ABORT_RECEIVED"},
    {21, "FLASH_PAGE_MISMATCH"},
    {22, "FLASH_BLOCK_MISMATCH"},
    {23, "FLASH_PAGE_NOT_IN_CODE_AREA"},
    {24, "MEM_ILLEGAL_ADDRESS"},
    {25, "FLASH_LOCKED"},
    {26, "INVALID_BLOCK"},
    {27, "FLASH_ILLEGAL_PAGE"},
    {28, "FLASH_TOO_MANY_BYTES"},
    {29, "FLASH_INVALID_STRING_NUM"},
    {48, "STREAM_IS_ACTIVE"},
    {49, "STREAM_TABLE_INVALID"},
    {50, "STREAM_CONFIG_INVALID"},
    {51, "STREAM_BAD_TRIGGER_SOURCE"},
    {52, "STREAM_NOT_RUNNING"},
    {53, "STREAM_INVALID_TRIGGER"},
    {54, "STREAM_ADC0_BUFFER_OVERFLOW"},
    {55, "STREAM_SCAN_OVERLAP"},
    {56, "STREAM_SAMPLE_NUM_INVALID"},
    {57, "STREAM_BIPOLAR_GAIN_INVALID"},
    {58, "STREAM_SCAN_RATE_INVALID"},
    {64, "TIMER_INVALID_MODE"},
    {65, "TIMER_QUADRATURE_AB_ERROR"},
    {66, "TIMER_QUAD_PULSE_SEQUENCE"},
    {67, "TIMER_BAD_CLOCK_SOURCE"},
    {68, "TIMER_STREAM_ACTIVE"},
    {69, "TIMER_PWMSTOP_MODULE_ERROR"},
    {70, "TIMER_SEQUENCE_ERROR"},
    {71, "TIMER_LINE_SEQUENCE_ERROR"},
    {72, "TIMER_SHARING_ERROR"},
    {80, "EXT_OSC_NOT_STABLE"},
    {81, "INVALID_POWER_SETTING"},
    {82, "PLL_NOT_LOCKED"},
    {96, "INVALID_PIN"},
    {97, "PIN_CONFIGURED_FOR_ANALOG"},
    {98, "PIN_CONFIGURED_FOR_DIGITAL"},
    {99, "IOTYPE_SYNCH_ERROR"},
    {100, "INVALID_OFFSET"},
    {101, "IOTYPE_NOT_VALID"},
    {999, "ERROR TEXT NOT AVAILABLE/FOUND"}
  };

  int x;

  for( x=0; errorText[x].code != code && errorText[x].code != 999; x++ );
  return  errorText[x].text;

  //return  "Error in method u3Base::getErrorText(..)";
}



u3Base::u3Base( int devicePath )
{
  int n;

  strcpy( lastError, "" );
  //
  //  Initialize FECioTable for LabJack U3
  //
  //      Human reference and label         Machine reference
  strcpy( FECioTable[0].fecios,  "FIO0" );  FECioTable[0].fecion  = 0;
  strcpy( FECioTable[1].fecios,  "FIO1" );  FECioTable[1].fecion  = 1;
  strcpy( FECioTable[2].fecios,  "FIO2" );  FECioTable[2].fecion  = 2;
  strcpy( FECioTable[3].fecios,  "FIO3" );  FECioTable[3].fecion  = 3;
  strcpy( FECioTable[4].fecios,  "FIO4" );  FECioTable[4].fecion  = 4;
  strcpy( FECioTable[5].fecios,  "FIO5" );  FECioTable[5].fecion  = 5;
  strcpy( FECioTable[6].fecios,  "FIO6" );  FECioTable[6].fecion  = 6;
  strcpy( FECioTable[7].fecios,  "FIO7" );  FECioTable[7].fecion  = 7;
  strcpy( FECioTable[8].fecios,  "FIOT" );  FECioTable[8].fecion  = 30;
  strcpy( FECioTable[9].fecios,  "EIO0" );  FECioTable[9].fecion  = 8;
  strcpy( FECioTable[10].fecios, "EIO1" );  FECioTable[10].fecion = 9;
  strcpy( FECioTable[11].fecios, "EIO2" );  FECioTable[11].fecion = 10;
  strcpy( FECioTable[12].fecios, "EIO3" );  FECioTable[12].fecion = 11;
  strcpy( FECioTable[13].fecios, "EIO4" );  FECioTable[13].fecion = 12;
  strcpy( FECioTable[14].fecios, "EIO5" );  FECioTable[14].fecion = 13;
  strcpy( FECioTable[15].fecios, "EIO6" );  FECioTable[15].fecion = 14;
  strcpy( FECioTable[16].fecios, "EIO7" );  FECioTable[16].fecion = 15;
  strcpy( FECioTable[17].fecios, "CIO0" );  FECioTable[17].fecion = 16;
  strcpy( FECioTable[18].fecios, "CIO1" );  FECioTable[18].fecion = 17;
  strcpy( FECioTable[19].fecios, "CIO2" );  FECioTable[19].fecion = 18;
  strcpy( FECioTable[20].fecios, "CIO3" );  FECioTable[20].fecion = 19;
  strcpy( FECioTable[21].fecios, "DAC0" );  FECioTable[21].fecion = 0;
  strcpy( FECioTable[22].fecios, "DAC1" );  FECioTable[22].fecion = 1;
  strcpy( FECioTable[23].fecios, "RCT0" );  FECioTable[23].fecion = 64;
  strcpy( FECioTable[24].fecios, "RCT1" );  FECioTable[24].fecion = 65;
  strcpy( FECioTable[25].fecios, "SSW0" );  FECioTable[25].fecion = 0;
  strcpy( FECioTable[26].fecios, "SSW1" );  FECioTable[26].fecion = 1;
  strcpy( FECioTable[27].fecios, "SSW2" );  FECioTable[27].fecion = 2;
  strcpy( FECioTable[28].fecios, "SSW3" );  FECioTable[28].fecion = 3;
  strcpy( FECioTable[29].fecios, "SSW4" );  FECioTable[29].fecion = 4;
  strcpy( FECioTable[30].fecios, "SSW5" );  FECioTable[30].fecion = 5;
  strcpy( FECioTable[31].fecios, "SSW6" );  FECioTable[31].fecion = 6;
  strcpy( FECioTable[32].fecios, "SSW7" );  FECioTable[32].fecion = 7;
  strcpy( FECioTable[33].fecios, "SSW8" );  FECioTable[33].fecion = 8;
  strcpy( FECioTable[34].fecios, "SSW9" );  FECioTable[34].fecion = 9;
  strcpy( FECioTable[35].fecios, "Fail" );  FECioTable[35].fecion = -1;

  if( devicePath != 0 ) {
    openUSBConnection( devicePath );
  } else {
    openUSBConnection( U3_DEVICE_PATH );
  }

  //
  //  Clear logic table
  //
  for( n=0; n<U3IOALEN; n++ ) {
    logTab[n].lOutput[0] = '\0';
    logTab[n].lInput[0] = '\0';
  }
  logTabEnd = 0;

  //
  //  Clear relayOut table
  //
  for( n=0; n<U3IOALEN; n++ ) {
    relayOut[n].logState    = -1;
    relayOut[n].offText[0]  = '\0';
    relayOut[n].onText[0]   = '\0';
    relayOut[n].offDelay    = 0;
    relayOut[n].onDelay     = 0;
    relayOut[n].offRemain   = 0;
    relayOut[n].onRemain    = 0;
  }

  //
  //  Set all software switches to false
  //
  for( n = 0; n < 10; n++ ) {
    ssw[n] = 0;
  }

  //
  //  Initially no shared memory
  //
  shmid = 0;

  //
  //  Initial state is that logic state has changed, because
  //  there is no prev. checkAllInputs() to refer to.
  //
  logicChange = 1;

  //
  //  Assume LV version of U3
  //
  hvVersion   = 0;
}  // u3Base::u3Base()



u3Base::~u3Base( void )
{
  closeUSBConnection();
  if( shmid > 0 ) {
    unlink( SHM_FILE_NAME );
    if( shmdt( shareptr ) < 0 ) {
      sprintf( lastError, "Error: failed to detach from shared memory with ID %d\n", shmid );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
    }
    if( shmctl( shmid, IPC_RMID, 0 ) < 0 ) {
      sprintf( lastError, "Error: removal of shared memory with ID %d failed\n", shmid );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
    }
  }
} //  u3Base::~u3Base()



HANDLE  u3Base::getConnecID( void )
{
  return  fd;
} //  getConnecID()


int     u3Base::FECioToNum( const char *sFECio )
{
  int   n;

  n = 0;
  while( strcmp( FECioTable[n].fecios, sFECio ) != 0 && strcmp( FECioTable[n].fecios, "Fail" ) != 0 )
  {
    n++;
  }
  return  FECioTable[n].fecion;
} //  FECioToNum(...)



int     u3Base::sendCommandU3( uint8* sendBuf, ULONG sendLen )
{
  ULONG sentChars;
 
  //Sending command to U3
  extendedChecksum( sendBuf, sendLen );

  if( ( sentChars =  LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuf, sendLen ) ) < sendLen )
  // Writes to a bulk endpoint.  Returns the count of the number of bytes wrote,
  // or 0 on error and sets errno.
  // hDevice = Handle of the LabJack USB device.
  // Pipe = The pipe you want to write your data through (xxx_PIPE_xxx_OUT).
  // *pBuff = Pointer to the buffer that will be written to the device.
  // Count = The size of the buffer to be written to the device.

  {
    if( sentChars == 0 ) {
      sprintf( lastError, "Send error : write failed in %s\n", __PRETTY_FUNCTION__ );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
    } else {
      sprintf( lastError, "Send error : did not write all of the buffer (%d/%d)\n", (int)sentChars,  (int)sendLen );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
    }
    return  -1;
  }
  return  0;
} //  sendCommandU3(...)



int     u3Base::recCommandU3( uint8* recBuf, ULONG recLen )
{
  ULONG recChars;
  uint16 checksumTotal;

  //Reading response from U3

  if( ( recChars =  LJUSB_BulkRead( fd, U3_PIPE_EP2_IN, recBuf, recLen ) ) < recLen )
  // Reads from a bulk endpoint.  Returns the count of the number of bytes read,
  // or 0 on error (and sets errno).  If there is no response within a certain
  // amount of time (LJ_LIBUSB_TIMEOUT in labjackusb.c), the read will timeout.
  // hDevice = Handle of the LabJack USB device.
  // Pipe = The pipe you want to read your data through (xxx_PIPE_xxx_IN).
  // *pBuff = Pointer a buffer that will be read from the device.
  // Count = The size of the buffer to be read from the device.
  {
    if(recChars == 0 )
    {
      sprintf( lastError, "Receive error : read failed\nError: %d - %s at frame %d\n",
                recBuf[6], getErrorText( recBuf[6] ), recBuf[7] );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
    } else {
      sprintf( lastError,
                "Receive error : did not read all of the expected buffer ( (%d/%d))\nError: %d - %s\n",
                (int)recChars, (int)recLen, recBuf[6], getErrorText( recBuf[6] ) );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
    }
    return -1;
  }
  checksumTotal = extendedChecksum16( recBuf, recChars);
  if( (uint8)((checksumTotal >> 8) & 0xff) != recBuf[5])
  {
    sprintf( lastError, "Receive error : read buffer has bad checksum16(MSB)\n" );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( (uint8)(checksumTotal & 0xff) != recBuf[4])
  {
    sprintf( lastError, "Receive error : read buffer has bad checksum16(LBS)\n" );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( extendedChecksum8( recBuf ) != recBuf[0])
  {
    sprintf( lastError, "Receive error : read buffer has bad checksum8\n" );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1; 
  }

  return 0;
} //  recCommandU3(...)



void    u3Base::normalChecksum( uint8 *b, int n )
{
  /* Add checksum to a data packet for normal command format */
  b[0] = normalChecksum8( b, n );
}


void    u3Base::extendedChecksum( uint8 *b, int n )
{
  /* Add checksum to a data packet for extended command format */

  uint16  a;

  a     = extendedChecksum16( b, n );
  b[4]  = (uint8)(a & 0xff);
  b[5]  = (uint8)((a >> 8) & 0xff);
  b[0]  = extendedChecksum8( b );
}

uint8   u3Base::normalChecksum8( uint8 *b, int n )
{
  /* Sum bytes 1 to n-1 as uint16. Sum quotient and remainder of 256
     division. Again, sum quotient and remainder of 256
     division. Return result as uint8.  */
  int     i;
  uint16  a, bb;
  
  for( i = 1, a = 0; i < n; i++ ) 
  {
    a += (uint16)b[i];
	}

  bb = a/256;
  a  = (a-256*bb)+bb;
  bb = a/256;

  return  (uint8)((a-256*bb)+bb);

}


uint16  u3Base::extendedChecksum16( uint8 *b, int n )
{
  /* Sum bytes 6 to n-1 as uint16. */

  int i,a = 0;

  for(i = 6; i < n; i++)
    a += (uint16)b[i];

  return  a;
}


uint8   u3Base::extendedChecksum8( uint8 *b )
{
  /* Sum bytes 1 to 5. Sum quotient and remainder of 256
     division. Again, sum quotient and remainder of 256
     division. Return result as uint8. */
  int i,a,bb;

  for(i=1,a=0;i<6;i++)
    a+=(uint16)b[i];
  
  bb=a/256;
  a=(a-256*bb)+bb;
  bb=a/256;
  
  return  (uint8)((a-256*bb)+bb);  
}



HANDLE  u3Base::openUSBConnection( int pathname )
{
  /* Opens a USB device. Returns a value <0 on failure. Returns the file
     descriptor on success. */
  fd = LJUSB_OpenDevice( pathname, 0, U3_PRODUCT_ID );
  // HANDLE LJUSB_OpenDevice(UINT DevNum, DWORD dwReserved, ULONG ProductID);
  //Obtains a handle for a LabJack USB device.  Returns NULL if there is an
  //error.  If the device is already open, NULL is returned and errno is set to
  //EBUSY.
  //DevNum = The device number of the LabJack USB device you want to open.  For
  //         example, if there is one device connected, set DevNum = 1.  If you
  //         have two devices connected, then set DevNum = 1, or DevNum = 2.
  //dwReserved = Not used, set to 0.
  //ProductID = The product ID of the LabJack USB device.  Currently the U3, U6,
  //            and UE9 are supported.

  // fd = open( pathname, O_RDWR );
  if( fd == NULL ) {
    sprintf( lastError, "Error: Could not open the device: %d\n", pathname );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
  }
  return  fd;
} //  openUSBConnection(...)



int     u3Base::closeUSBConnection( void )
{
  if( fd != NULL ) {
    LJUSB_CloseDevice( fd );
    return  0;
  } else {
    return  -1;
  }
} //  int closeUSBConnection(...)




//
//  Set relay nr ( 8..10, 16..17 ) to state ( 0, 1 )
//  Return 0 if OK else -1
//
int     u3Base::setRelay( const char *sFECio, int state )
{
  return  setRelay( FECioToNum( sFECio ), state );
} //  setRelay(...)



int     u3Base::setRelay( int outputNumber,   //  Port 8..19
                          int state )         //  0=Off, !0=On
{
  if( outputNumber == -1 ) {
    return  -1;
  }
  if( outputNumber >= U3IOALEN ) {
    return  -1;
  }
  //
  //  First check if timer is involved and/or if state is different from current or unkown
  //
  if( relayOut[outputNumber].logState >= 0 ) {
    if( relayOut[outputNumber].logState == state ) {
      relayOut[outputNumber].offRemain  = 0;  //  Reset timer
      relayOut[outputNumber].onRemain   = 0;  //  Reset timer
      return  0;  //  Relay is already in that state
    }
    if( state == 0 ) {  //  hi --> lo
      if( relayOut[outputNumber].offDelay > 0 ) { //  Use timer
        if( relayOut[outputNumber].offRemain == 0 ) { //  Set timer
          relayOut[outputNumber].offRemain = relayOut[outputNumber].offDelay + time( NULL );
          return  0;
        } else {
          if(  time( NULL ) >= relayOut[outputNumber].offRemain ) { //  Time has run out
            relayOut[outputNumber].offRemain = 0;   //  Reset timer
          } else {
            return  0;  //  Wait a bit longer
          }
        }
      }
    } else {  //  lo --> hi
      if( relayOut[outputNumber].onDelay > 0 ) { //  Use timer
        if( relayOut[outputNumber].onRemain == 0 ) { //  Set timer
          relayOut[outputNumber].onRemain = relayOut[outputNumber].onDelay + time( NULL );
          return  0;
        } else {
          if(  time( NULL ) >= relayOut[outputNumber].onRemain ) { //  Time has run out
            relayOut[outputNumber].onRemain = 0;    //  Reset timer
          } else {
            return  0;  //  Wait a bit longer
          }
        }
      }
    }
  } else {
    //  The current relay state is not know (predefined as -1).
  }

  //  time_t	time (time_t *tloc)

  //------------------
  sendBuff2[0] = 0;
  sendBuff2[1] = (uint8)(0xF8);  //Command byte
  sendBuff2[2] = 2;
  sendBuff2[3] = (uint8)(0x00);  //Extended command number
  sendBuff2[4] = 0;
  sendBuff2[5] = 0;
  //------------------
  sendBuff2[6] = 0;    //Echo  

  sendBuff2[7] = 11;   //IOType is BitStateWrite  (CIO0)
  relayOut[outputNumber].logState = state;                //  True state of relay setting
  if( outputNumber > 7 ) {                                //  Lines on term. board is inverted
    state = !state;
  }
  if( state != 0 ) {                                              //  Set the state+relay number
    sendBuff2[8] = (uint8) (128 + outputNumber);  //  Set relay
  } else {
    sendBuff2[8] = (uint8) (  0 + outputNumber);  //  Reset relay
  }
  //------------------
  //Sending command to U3
  if( sendCommandU3( sendBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error sendCommandU3: setRelay( %d, %d )\n", outputNumber, state );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: setRelay( %d, %d )\n", outputNumber, state );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  setRelay(...)



int     u3Base::writeConf(  const char *FIOAnalog,  //  "11111111"
                            const char *EIOAnalog,  //  "00000000"
                            const char *DirFIO,     //  "00000000"
                            const char *DirEIO,     //  "00000111"
                            const char *DirCIO,     //  "00000011"
                            const char *cntIO0,     //  ""=no counter0 else "FIO0".."EIO7"
                            const char *cntIO1 )    //  ""=no counter1 else "FIO0".."EIO7"
{
  uint8 cTemp;

  strcpy( cnt0, cntIO0 );
  strcpy( cnt1, cntIO1 );
  sendBuff[0]  = 0;
  sendBuff[1]  = (uint8)(0xF8);                         //Command byte
  sendBuff[2]  = 3;
  sendBuff[3]  = (uint8)(0x0B);                         //Extended command number
  sendBuff[4]  = 0;
  sendBuff[5]  = 0;
  //------------------
  if( strlen( cnt0 ) > 0 ) {
    sendBuff[6]  = (uint8) binToInt("01101");     //Write mask  
  } else {
    sendBuff[6]  = (uint8) binToInt("01100");     //Write mask  
  }
  sendBuff[7]  = (uint8) 0;                     //Resrved
  if( strlen( cnt0 ) > 0 ) {  //TimerCounterConfig
    if( strlen( cnt1 ) == 0 ) {
      sendBuff[8]  = (uint8) ( ( FECioToNum( cnt0 ) << 4 ) + 4 );
    } else {
      sendBuff[8]  = (uint8) ( ( FECioToNum( cnt0 ) << 4 ) + 4 + 8 );
    }
  } else {
    sendBuff[8]  = (uint8) 0;
  }
  sendBuff[9]  = (uint8) binToInt(      "00");  //DAC1Enable
  sendBuff[10] = (uint8) binToInt( FIOAnalog ); //FIOAnalog
  sendBuff[11] = (uint8) binToInt( EIOAnalog ); //EIOAnalog
  //------------------
  if( sendCommandU3( sendBuff, 12 ) != 0 ) return -1;
  //------------------
  if( recCommandU3( recBuff, 12 ) != 0 ) return -1;

  //
  //  Sort out direction of logic channels
  //
  //------------------
  sendBuff[0] = (uint8) 0;
  sendBuff[1] = (uint8)(0xF8);  //Command byte
  sendBuff[2] = (uint8) 4;
  sendBuff[3] = (uint8)(0x00);  //Extended command number
  sendBuff[4] = (uint8) 0;
  sendBuff[5] = (uint8) 0;
  //------------------
  sendBuff[6] = (uint8) 0;      //Echo  
  //------------------
  sendBuff[7] = (uint8) 29;     //Command byte for direction of logic lines

  cTemp = binToInt( FIOAnalog ) ^ binToInt( "11111111" ); //Analog lines cannot be logic
  cTemp = cTemp & binToInt( "11111111" );                 //These lines exists FIO7..FIO0
  sendBuff[8]= (uint8) binToInt("11111111") & cTemp;      //Write mask FIO original: binToInt("00000000")

  cTemp = binToInt( EIOAnalog ) ^ binToInt( "11111111" ); //Analog lines cannot be logic
  cTemp = cTemp & binToInt( "11111111" );                 //These lines exists EIO7..EIO0
  sendBuff[9] = (uint8) binToInt("11111111") & cTemp;     //Write mask EIO

  cTemp = binToInt( "00000000" ) ^ binToInt( "11111111" );//Analog lines cannot be logic (none on CIOx)
  cTemp = binToInt( "00001111" );                         //These lines exists CIO3..CIO0
  sendBuff[10] = (uint8) binToInt("00001111") & cTemp;    //Write mask CIO

                                //1=Output and 0=Input
  sendBuff[11]= (uint8) binToInt( DirFIO );   //Direction  FIO
  sendBuff[12]= (uint8) binToInt( DirEIO );   //Direction  EIO
  sendBuff[13]= (uint8) binToInt( DirCIO );   //Direction  CIO
  //------------------
  if( sendCommandU3( sendBuff, 14 ) != 0 ) return -1;
  if( recCommandU3( recBuff, 10 ) != 0 ) return -1;
  //------------------
  return  0;
} //  writeConf()



int     u3Base::writeConf(  const char *FIOAnalog,  //  "11111111"
                            const char *EIOAnalog,  //  "00000000"
                            const char *DirFIO,     //  "00000000"
                            const char *DirEIO,     //  "00000111"
                            const char *DirCIO,     //  "00000011"
                            const char *stateFIO,   //  "00000000"
                            const char *stateEIO,   //  "00000000"
                            const char *stateCIO,   //  "0000"
                            const char *cntIO0,     //  ""=no counter0 else "FIO0".."EIO7"
                            const char *cntIO1 )    //  ""=no counter1 else "FIO0".."EIO7"
{
  strcpy( cnt0, cntIO0 );
  strcpy( cnt1, cntIO1 );
  sendBuff[0]  = 0;
  sendBuff[1]  = (uint8)(0xF8);                         //Command byte
  sendBuff[2]  = 10;                                    //Datawords
  sendBuff[3]  = (uint8)(0x08);                         //Extended command number
  sendBuff[4]  = 0;
  sendBuff[5]  = 0;
  //------------------
  /*
  WriteMask0
            Bit 3: LocalID
            Bit 2: DAC Defaults
            Bit 1: Digital I/O Defaults
            Bit 0: Reserved
                                       3210 */
  sendBuff[6]  = (uint8) binToInt("00000010");        //Write mask0
  sendBuff[7]  = (uint8) 0;                           //Write mask1 resrved
  sendBuff[8]  = (uint8) 1;                           //Local ID
  /*
  TimerCounterConfig
           Bits 4-7: TimerCounterPinOffset
           Bit 3: Enable Counter1
           Bit 2: Enable Counter0
           Bits 0-1: Number of timers enabled
  */
  if( strlen( cnt0 ) > 0 ) {  //TimerCounterConfig
    if( strlen( cnt1 ) == 0 ) {
      sendBuff[9]  = (uint8) ( FECioToNum( cnt0 ) << (4 + 4) );
    } else {
      sendBuff[9]  = (uint8) ( FECioToNum( cnt0 ) << (4 + 4 + 8) );
    }
  } else {
    sendBuff[9]  = (uint8) 0;
  }

  sendBuff[10] = (uint8) binToInt( FIOAnalog ) & 255; //FIOAnalog
  sendBuff[11] = (uint8) binToInt( DirFIO    ) & 255; //FIODirection
  sendBuff[12] = (uint8) binToInt( stateFIO  ) ^ 255; //FIOState

  sendBuff[13] = (uint8) binToInt( EIOAnalog ) & 255; //EIOAnalog
  sendBuff[14] = (uint8) binToInt( DirEIO    ) & 255; //EIODirection
  sendBuff[15] = (uint8) binToInt( stateEIO  ) ^ 255; //EIOState

  sendBuff[16] = (uint8) binToInt( DirCIO    ) & 255; //CIODirection
  sendBuff[17] = (uint8) binToInt( stateCIO  ) ^ 255; //CIOState

  sendBuff[18] = (uint8) binToInt("00000000");        //DAC1Enable

  sendBuff[19] = (uint8) binToInt("00000000");        //DAC0
  sendBuff[20] = (uint8) binToInt("00000000");        //DAC1
  sendBuff[21] = (uint8) binToInt("00000000");
  sendBuff[22] = (uint8) binToInt("00000000");
  sendBuff[23] = (uint8) binToInt("00000000");
  sendBuff[24] = (uint8) binToInt("00000000");
  sendBuff[25] = (uint8) binToInt("00000000");

  if( sendCommandU3( sendBuff, 26 ) != 0 ) {
    return -1;
  }
  if( recCommandU3( recBuff, 38 ) != 0 ) {
    return -1;
  }

  //
  //  Determine the versionInfo and thereby hvVersion true or false
  //  Added Nov 2009
  //
  versionInfo = (uint8) recBuff[37];  //  1=U3B 2=U3C 4=  8=  16=HV
  hvVersion   = ( ( versionInfo & 2 ) == 2 ) && ( ( versionInfo & 16 ) == 16 );

  return  0;
} //  writeConf()



void    u3Base::printU3configuration( void )
{
  printf("U3 Configuration Settings:\n");
  printf("FirmwareVersion       : %.3f\n", recBuff[10] + recBuff[9]/100.0);
  printf("BootloaderVersion     : %.3f\n", recBuff[12] + recBuff[11]/100.0);
  printf("HardwareVersion       : %.3f\n", recBuff[14] + recBuff[13]/100.0);
  printf("SerialNumber          : %u\n", recBuff[15] + recBuff[16]*256 + recBuff[17]*65536 + recBuff[18]*16777216);
  printf("ProductID             : %d\n", recBuff[19] + recBuff[20]*256);
  printf("LocalID               : %8d\n", recBuff[21]);
  printf("FIOAnalog (FIO7-0)    : %s\n", intToBin( recBuff[23], 0 ) );
  printf("FIODirection (FIO7-0) : %s\n", intToBin( recBuff[24], 0 ) );
  printf("FIOState (FIO7-0)     : %s\n", intToBin( recBuff[25], 0 ) );
  printf("EIOAnalog (EIO7-0)    : %s\n", intToBin( recBuff[26], 0 ) );
  printf("EIODirection (EIO7-0) : %s\n", intToBin( recBuff[27], 0 ) );
  printf("EIOState (EIO0-7)     : %s\n", intToBin( recBuff[28], 0 ) );
  printf("CIODirection (CIO3-0) :     %s\n", intToBin( recBuff[29], 0 ) );
  printf("CIOState (CIO3-0)     :     %s\n", intToBin( recBuff[30], 0 ) );
  printf("DAC1Enable            : %8d\n", recBuff[31]);
  printf("DAC0 (in byte form)   : %8d ~ %s\n", recBuff[32], intToBin( recBuff[32], 0 ) );
  printf("DAC1 (in byte form)   : %8d ~ %s\n", recBuff[33], intToBin( recBuff[33], 0 ) );    
} //  printU3configuration(...)



void    u3Base::setRelayText( const char *sFECio,
                              const char *offText,
                              const char *onText )
{
  strcpy( relayOut[FECioToNum( sFECio )].offText, offText );
  strcpy( relayOut[FECioToNum( sFECio )].onText, onText );
} //  setRelayText(...)



const char*   u3Base::getRelayText( const char *sFECio )
{
  if( relayOut[FECioToNum( sFECio )].logState == 0 ) {
    return  relayOut[FECioToNum( sFECio )].offText;
  } else {
    return  relayOut[FECioToNum( sFECio )].onText;
  }
} //  getRelayText(...)



void    u3Base::setRelayDelay(  const char  *sFECio,      //  FIO0..7, EIO0..7, CIO0..3
                                time_t      offDelay,     //  Propagation delay time in seconds
                                time_t      onDelay )     //  Propagation delay time in seconds
{
  relayOut[FECioToNum( sFECio )].offDelay = offDelay;
  relayOut[FECioToNum( sFECio )].onDelay  = onDelay;
} //  setRelayDelay(...)



int     u3Base::getSSW( const char  *sFECio )             //  SSW0..9
{
  return  ssw[FECioToNum( sFECio )];
} //  getSSW(...)



int     u3Base::setSSW( const char  *sFECio )             //  SSW0..9, !SSW0..9
{
  char  s[6];
  int   neg;

  if( strlen( sFECio ) >= 6 ) {
    return -1;
  }
  if( sFECio[0] == '!' ) {
    neg = 1;
    strcpy( s, &sFECio[1] );
  } else {
    neg = 0;
    strcpy( s, sFECio );
  }
  if( FECioToNum( s ) == -1 ) {
    return -1;
  }
  if( ssw[FECioToNum( s )] != (1 ^ neg) ) {
    logicChange = 1;
  }
  ssw[FECioToNum( s )] = 1 ^ neg;
  if( shmid > 0 ) {
    shareptr->ssw[FECioToNum( s )] = 1 ^ neg;
  }
  return  0;
} //  setSSW(...)



void    u3Base::buildInputCommandDelay(const char *sFECio,      //  FIO0..7, EIO0..7, CIO0..3
                                      time_t      offDelay,     //  Propagation delay time in seconds
                                      time_t      onDelay )     //  Propagation delay time in seconds
{
  if( getConfTableNum( sFECio ) != -1 ) {
    confTable[getConfTableNum( sFECio )].offDelay = offDelay;
    confTable[getConfTableNum( sFECio )].onDelay  = onDelay;
  } else {
    sprintf( lastError, "Error: Input %s is not defined using buildInputCommad...\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
  }
} //  buildInputCommandDelay(...)



int     u3Base::getRelayState( const char *sFECio )
{
  if( FECioToNum( sFECio ) != -1 ) {
    return  relayOut[FECioToNum( sFECio )].logState;
  } else {
    return  -1;
  }
} //  getRelayState(...)



const char*   u3Base::getInputFECio(  int inputNumber )
{
  if( inputNumber >= 0 && inputNumber < U3IOALEN) {
    return  confTable[inputNumber].u3Pos;
  } else {
    return  "Error: wrong inputNumber in u3Base::getInputFECio(int inputNumber)\n";
  }
} //  getInputFECio(...)



int     u3Base::getInputState( const char *sFECio )     //  Logic input
{
  return  getInputState( getConfTableNum( sFECio ) );
} //  getInputState(...)



int     u3Base::getInputState( int  inputNumber )       //  Logic input
{
  //if( inputNumber != -1 && ( confTable[inputNumber].typeAD == 'D' || confTable[inputNumber].typeAD == 'C' ) ) {
  if( inputNumber != -1 ) {
    return  confTable[inputNumber].logState;
  } else {
    return  -1;
  }
} //  getInputState(...)



double  u3Base::getInputVoltage( const char *sFECio )   //  Analog input
{
  return  getInputVoltage( getConfTableNum( sFECio ) );
} //  getInputVoltage(...)



double  u3Base::getInputVoltage( int  inputNumber )     //  Analog input
{
  if( inputNumber != -1 && confTable[inputNumber].typeAD == 'A' ) {
    return  confTable[inputNumber].voltage;
  } else {
    return  0.0;
  }
} //  getInputVoltage(...)



long    u3Base::getInputCount(  const char  *sFECio )     //  FIO0..7, EIO0..1 Counter input
{
  return  getInputCount( getConfTableNum( sFECio ) );
} //  getInputCount(...)



long    u3Base::getInputCount(  int         inputNumber ) //  Counter input
{
  if( inputNumber != -1 && confTable[inputNumber].typeAD == 'C' ) {
    return  confTable[inputNumber].counter;
  } else {
    return  0;
  }
} //  getInputCount(...)



int     u3Base::resetCounter(   int         cntNum )      //  0=counter0 1=counter1
{
  //------------------
  sendBuff2[0] = 0;
  sendBuff2[1] = (uint8)(0xF8);  //Command byte
  sendBuff2[2] = 2;
  sendBuff2[3] = (uint8)(0x00);  //Extended command number
  sendBuff2[4] = 0;
  sendBuff2[5] = 0;
  //------------------
  sendBuff2[6] = 0;    //Echo  

  sendBuff2[7] = (uint8) (54+cntNum); //IOType is counter0 or counter1
  sendBuff2[8] = 1;                   //  Reset counter
  //------------------
  //Sending command to U3
  if( sendCommandU3( sendBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error sendCommandU3: resetCounter( %d )\n", cntNum );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff2, 14 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: resetCounter( %d )\n", cntNum );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return  0;
} //  resetCounter(...)



const char*   u3Base::getInputText( int inputNumber ) //  Analog input
{
  if( inputNumber != -1 ) {
    return  confTable[inputNumber].remarks;
  } else {
    return  "Unknown inputNumber in u3Base::getInputText(...)\n";
  }
} //  getInputText(...)



const char*   u3Base::getInputText( const char *sFECio )  //  Analog input
{
  return  getInputText( getConfTableNum( sFECio ) );
} //  getInputText(...)



                    //  Get all info for an input in a structConfTable variable
int     u3Base::getConfTable( int         inputNumber,  //  0..U3IOALEN
                              structConfTable *table )  //  User variable to retrieve the lot
{
  if( inputNumber >= 0 && inputNumber < U3IOALEN ) {
    memcpy( table, &confTable[inputNumber], sizeof( structConfTable ) );
    return 0;
  } else {
    return -1;
  }
} //  getConfTable(...)



                    //  Get all info for an input in a structConfTable variable
int     u3Base::getConfTable( const char  *sFECio,      //  FIO0..7, FIOT, EIO0..7, CIO0..3 Input
                              structConfTable *table )  //  User variable to retrieve the lot
{
  return  getConfTable( getConfTableNum( sFECio ), table );
} //  getConfTable(...)



                    //  Get all info for an output in a structRelayOut variable
int     u3Base::getRelayOut(  int         outputNumber, //  0..U3IOALEN
                              structRelayOut *table )   //  User variable to retrieve the lot
{
  if( outputNumber >= 0 && outputNumber < U3IOALEN ) {
    memcpy( table, &relayOut[outputNumber], sizeof( structRelayOut ) );
    return 0;
  } else {
    return -1;
  }
} //  getConfTable(...)



                        //  Get all info for an output in a structRelayOut variable
int     u3Base::getRelayOut(  const char  *sFECio,      //  FIO0..7, FIOT, EIO0..7, CIO0..3
                              structRelayOut *table )   //  User variable to retrieve the lot
{
  return  getRelayOut( FECioToNum( sFECio ), table );
} //  getRelayOut(...)



//
//  Look up position in confTable of u3Pos.
//  Return position as integer value on success or -1 on error (not found).
//
int     u3Base::getConfTableNum( const char *sFECio)
{
  int n;

  n=0;
  while( strcmp( confTable[n].u3Pos, sFECio ) != 0 && n < U3IOALEN ) n++;
  if( n < U3IOALEN ) {
    return  n;
  } else {
    return  -1;
  }
} //  getConfTableNum(...)



int     u3Base::binToInt( const char *s )
{
  int imax, i, ret, fact;

  for( imax=0; s[imax] != 0; imax++ );
  ret=0;
  fact=1;
  imax--;
  for( i=imax; i>=0; i-- ) {
    if( s[i]=='1' ) {
      ret+=fact;
    }
    fact = fact * 2;
  }
  return  ret;
} //  binToInt(...)



const char*   u3Base::intToBin( int i, int isWord )
{
  int ii, fact;

  if( isWord ) {
    for( ii=0; ii < 16; ii++ ) sBinRet[ii]=0;
    fact=32768; //  2^15
    for( ii=0; ii<16; ii++ ) {
      if( i >= fact ) {
        sBinRet[ii]='1';
        i -= fact;
      } else {
        sBinRet[ii]='0';
      }
      fact = (fact >> 1) & 0xffff;
    }
    sBinRet[15]='\0';
  } else {
    for( ii=0; ii < 8; ii++ ) sBinRet[ii]=0;
    fact=128; //  2^7
    for( ii=0; ii<8; ii++ ) {
      if( i >= fact ) {
        sBinRet[ii]='1';
        i -= fact;
      } else {
        sBinRet[ii]='0';
      }
      fact = (fact >> 1) & 0xff;
    }
    sBinRet[8]='\0';
  }
  return  sBinRet;

} //  intToBin(...)



void    u3Base::printSendBuff2( int nmax )
{
  int n;
  
  for( n=0; n<nmax; n++ ) {
    printf( "sendbuff2[%d] = %d\n", n, sendBuff2[n] );
  }
}


long    u3Base::getCalibrationInfo( void )
{
/*  Gets calibration information from memory blocks 0-2 of a U3 
    and stores the information into a calibrationInfo structure. */
   
  uint8 sendBuffer[8];
  uint8 recBuffer[40];
  int sentRec = 0;
  
  //////////////////////////////
  //reading block 0 from memory 
  //////////////////////////////
  sendBuffer[1] = (uint8)(0xF8);  //command byte
  sendBuffer[2] = (uint8)(0x01);  //number of data words
  sendBuffer[3] = (uint8)(0x2D);  //extended command number
  sendBuffer[6] = (uint8)(0x00);
  sendBuffer[7] = (uint8)(0x00);  //Blocknum = 0
  extendedChecksum(sendBuffer, 8);
  
  sentRec = LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuffer, 8 );
  if(sentRec < 8)
  {
    if(sentRec == -1)
      goto writeError0;
    else  
      goto writeError1;
  }	

  sentRec= LJUSB_BulkRead( fd, U3_PIPE_EP2_IN, recBuffer, 40 );
  if(sentRec < 40)
  {
    if(sentRec == -1)
      goto readError0;
    else  
      goto readError1;
  }

  if(recBuffer[1] != (uint8)(0xF8) || recBuffer[2] != (uint8)(0x11) || recBuffer[3] != (uint8)(0x2D))
    goto commandByteError;

  //block data starts on byte 8 of the buffer
  caliInfo.ainSESlope = FPuint8ArrayToFPDouble(recBuffer + 8, 0);
  caliInfo.ainSEOffset = FPuint8ArrayToFPDouble(recBuffer + 8, 8);
  caliInfo.ainDiffSlope = FPuint8ArrayToFPDouble(recBuffer + 8, 16);
  caliInfo.ainDiffOffset = FPuint8ArrayToFPDouble(recBuffer + 8, 24);
 
  //////////////////////////////
  //reading block 1 from memory 
  //////////////////////////////
  sendBuffer[7] = (uint8)(0x01);    //Blocknum = 1
  extendedChecksum(sendBuffer, 8);
  
  sentRec = LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuffer, 8 );
  if(sentRec < 8)
  {
    if(sentRec == -1)
      goto writeError0;
    else  
      goto writeError1;
  }	

  sentRec= LJUSB_BulkRead( fd, U3_PIPE_EP2_IN, recBuffer, 40 );

  if(sentRec < 40)
  {
    if(sentRec == -1)
      goto readError0;
    else  
      goto readError1;
  }

  if(recBuffer[1] != (uint8)(0xF8) || recBuffer[2] != (uint8)(0x11) || recBuffer[3] != (uint8)(0x2D))
  {
    goto commandByteError;
  }
  
  caliInfo.dacSlope[0] = FPuint8ArrayToFPDouble(recBuffer + 8, 0);
  caliInfo.dacOffset[0] = FPuint8ArrayToFPDouble(recBuffer + 8, 8);
  caliInfo.dacSlope[1] = FPuint8ArrayToFPDouble(recBuffer + 8, 16);
  caliInfo.dacOffset[1] = FPuint8ArrayToFPDouble(recBuffer + 8, 24);

  //////////////////////////////
  //reading block 2 from memory 
  //////////////////////////////
  sendBuffer[7] = (uint8)(0x02);    //Blocknum = 2
  extendedChecksum(sendBuffer, 8);
  
  sentRec = LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuffer, 8 );
  if(sentRec < 8)
  {
    if(sentRec == -1)
      goto writeError0;
    else  
      goto writeError1;
  }	

  sentRec= LJUSB_BulkRead( fd, U3_PIPE_EP2_IN, recBuffer, 40 );
  if(sentRec < 40)
  {
    if(sentRec == -1)
      goto readError0;
    else  
      goto readError1;
  }

  if(recBuffer[1] != (uint8)(0xF8) || recBuffer[2] != (uint8)(0x11) || recBuffer[3] != (uint8)(0x2D))
  {
    goto commandByteError;
  }
  
  caliInfo.tempSlope = FPuint8ArrayToFPDouble(recBuffer + 8, 0);
  caliInfo.vref = FPuint8ArrayToFPDouble(recBuffer + 8, 8);
  caliInfo.vref15 = FPuint8ArrayToFPDouble(recBuffer + 8, 16);
  caliInfo.vreg = FPuint8ArrayToFPDouble(recBuffer + 8, 24);

  if( hvVersion ) {   //  ---------- Start: High Voltage Version ------------
    //////////////////////////////
    //reading block 3 from memory 
    //////////////////////////////
    sendBuffer[7] = (uint8)(0x03);  //Blocknum = 3
    extendedChecksum(sendBuffer, 8);
    
    sentRec = LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuffer, 8 );
    if(sentRec < 8)
    {
      if(sentRec == -1)
        goto writeError0;
      else  
        goto writeError1;
    }	

    sentRec= LJUSB_BulkRead( fd, U3_PIPE_EP2_IN, recBuffer, 40 );
    if(sentRec < 40)
    {
      if(sentRec == -1)
        goto readError0;
      else  
        goto readError1;
    }

    if(recBuffer[1] != (uint8)(0xF8) || recBuffer[2] != (uint8)(0x11) || recBuffer[3] != (uint8)(0x2D))
      goto commandByteError;

    caliInfo.ain0HvSlope = FPuint8ArrayToFPDouble(recBuffer + 8, 0);
    caliInfo.ain1HvSlope = FPuint8ArrayToFPDouble(recBuffer + 8, 8);
    caliInfo.ain2HvSlope = FPuint8ArrayToFPDouble(recBuffer + 8, 16);
    caliInfo.ain3HvSlope = FPuint8ArrayToFPDouble(recBuffer + 8, 24);
   
    //////////////////////////////
    //reading block 4 from memory 
    //////////////////////////////
    sendBuffer[7] = (uint8)(0x04);    //Blocknum = 4
    extendedChecksum(sendBuffer, 8);
    
    sentRec = LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuffer, 8 );
    if(sentRec < 8)
    {
      if(sentRec == -1)
        goto writeError0;
      else  
        goto writeError1;
    }	

    sentRec= LJUSB_BulkRead( fd, U3_PIPE_EP2_IN, recBuffer, 40 );

    if(sentRec < 40)
    {
      if(sentRec == -1)
        goto readError0;
      else  
        goto readError1;
    }

    if(recBuffer[1] != (uint8)(0xF8) || recBuffer[2] != (uint8)(0x11) || recBuffer[3] != (uint8)(0x2D))
    {
      goto commandByteError;
    }
    
    caliInfo.ain0HvOffset = FPuint8ArrayToFPDouble(recBuffer + 8, 0);
    caliInfo.ain1HvOffset = FPuint8ArrayToFPDouble(recBuffer + 8, 8);
    caliInfo.ain2HvOffset = FPuint8ArrayToFPDouble(recBuffer + 8, 16);
    caliInfo.ain3HvOffset = FPuint8ArrayToFPDouble(recBuffer + 8, 24);
  }    //  ---------- End: High Voltage Version ------------

  return 0;
  
writeError0: 
  sprintf( lastError, "Error : getCalibrationInfo write failed\n" );
  if( PRINT_ERRORS ) {
    printf( "%s", lastError );
  }
  return -1;
  
writeError1:
  sprintf( lastError, "Error : getCalibrationInfo did not write all of the buffer\n" );
  if( PRINT_ERRORS ) {
    printf( "%s", lastError );
  }
  return -1;

readError0:
  sprintf( lastError, "Error : getCalibrationInfo read failed\n" );
  if( PRINT_ERRORS ) {
    printf( "%s", lastError );
  }
  return -1;
  
readError1:
  sprintf( lastError, "Error : getCalibrationInfo did not read all of the buffer\n" );
  if( PRINT_ERRORS ) {
    printf( "%s", lastError );
  }
  return -1;

commandByteError:
  sprintf( lastError, "Error : getCalibrationInfo received wrong command bytes for ReadMem\n" );
  if( PRINT_ERRORS ) {
    printf( "%s", lastError );
  }
  return -1;
} //  getCalibrationInfo()



double    u3Base::FPuint8ArrayToFPDouble(uint8 *buffer, int startIndex)
{
/*  Converts a fixed point byte array (starting a startIndex) to 
    a floating point double value  */
    
  unsigned int resultDec;
  int resultWh;
  int i;

  resultDec = 0;
  resultWh = 0;

  for(i = 0; i < 4; i++) 
  {
    resultDec += (buffer[startIndex + i] << (i*8)); 			
    resultWh += (buffer[startIndex + i + 4] << (i*8));
  }

  return ( (double)resultWh + (double)(resultDec)/4294967296.0 );
} //  FPuint8ArrayToFPDouble(...)



long    u3Base::binaryToCalibratedAnalogVoltage( int negChannel, uint16 bytesVoltage, double *analogVoltage)
{
/*  Translates the binary analog input bytes read from the u3, to a voltage 
    value (calibrated).  Call getCalibrationInfo first to set up caliInfo.  
    Returns -1 on error, 0 on success.  */
  
  if( ( negChannel >= 0 && negChannel < 16 ) || negChannel == 30 ) {
    if( hvVersion ) {
      *analogVoltage = caliInfo.ainDiffSlope*((double)bytesVoltage) + caliInfo.ainDiffOffset;
    } else {
      *analogVoltage = caliInfo.ainDiffSlope*((double)bytesVoltage) + caliInfo.ainDiffOffset;
    }
  } else if(negChannel == 31) {
    if( hvVersion ) {
      *analogVoltage = caliInfo.ainSESlope*((double)bytesVoltage) + caliInfo.ainSEOffset;
    } else {
      *analogVoltage = caliInfo.ainSESlope*((double)bytesVoltage) + caliInfo.ainSEOffset;
    }
  } else {
    sprintf( lastError, "Error: binaryToCalibratedAnalogVoltage(...) error: invalid negative channel %d.\n", negChannel );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }

  return 0;  
} //  binaryToCalibratedAnalogVoltage(...)



long    u3Base::binaryToCalibratedAnalogHvVoltage( int channelNumber, uint16 bytesVoltage, double *analogVoltage )
{
/*  Translates the binary analog input bytes read from the u3, to a voltage 
    value (calibrated).  Call getCalibrationInfo first to set up caliInfo.  
    Returns -1 on error, 0 on success.
    Currently always success  */

  switch( channelNumber ) {
    case 0:
      *analogVoltage = caliInfo.ain0HvSlope*((double)bytesVoltage) + caliInfo.ain0HvOffset;
      break;
    case 1:
      *analogVoltage = caliInfo.ain1HvSlope*((double)bytesVoltage) + caliInfo.ain1HvOffset;
      break;
    case 2:
      *analogVoltage = caliInfo.ain2HvSlope*((double)bytesVoltage) + caliInfo.ain2HvOffset;
      break;
    case 3:
      *analogVoltage = caliInfo.ain3HvSlope*((double)bytesVoltage) + caliInfo.ain3HvOffset;
      break;
    default:
      sprintf( lastError, "Error: binaryToCalibratedAnalogHvVoltage(...) error: invalid channel number %d.\n", channelNumber );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
      return -1;
  }      

  return 0;  
} //  binaryToCalibratedAnalogHvVoltage(...)



long    u3Base::binaryToCalibratedAnalogTemperature( uint16 bytesTemperature, double *analogTemperature )
{
/*  Translates the binary analog bytes read from the u3, to a Kelvin 
    temperature value (calibrated).  Call getCalibrationInfo first to 
    set up caliInfo.  Returns -1 on error, 0 on success.  */
  
  *analogTemperature = caliInfo.tempSlope*((double)bytesTemperature);
  return 0;
} //  binaryToCalibratedAnalogTemperature(...)



long    u3Base::analogToCalibratedBinaryVoltage( int channelNumber, double analogVoltage, uint8 *bytesVoltage )
{
/*  Translates a voltage value to binary analog input bytes (calibrated) 
    that can be sent to a u3.  Call getCalibrationInfo first to set up 
    caliInfo.  Returns -1 on error, 0 on success. */

  double tempBytesVoltage;
  
  tempBytesVoltage = (analogVoltage/4.95)*256;
  
  switch(channelNumber) 
  {
    case 0:
      tempBytesVoltage = analogVoltage*caliInfo.dacSlope[0] + caliInfo.dacOffset[0];
      break;
    case 1:
      tempBytesVoltage = analogVoltage*caliInfo.dacSlope[1] + caliInfo.dacOffset[1];      
      break;
    default:
      sprintf( lastError, "Error: analogToCalibratedBinaryVoltage(...) invalid channelNumber %d.\n", channelNumber );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
      return -1;
  }	
  //Checking to make sure bytesVoltage will be a value between 0 and 255, 
  //Too high of an analogVoltage (about 4.95 and above volts) or too low 
  //(below 0 volts) will cause a value not between 0 and 255.
  if(tempBytesVoltage < 0)
    tempBytesVoltage = 0;
  if(tempBytesVoltage > 255)  
    tempBytesVoltage = 255;
  
  *bytesVoltage = (uint8)tempBytesVoltage;

  return 0;
} //  analogToCalibratedBinaryVoltage(...)


		
long    u3Base::binaryToUncalibratedAnalogVoltage( int negChannel, uint16 bytesVoltage, double *analogVoltage )
{
/*  Translates the binary analog input bytes read from the u3, to 
    a voltage value (uncalibrated) */

  if( ( negChannel >= 0 && negChannel <= 15 ) || negChannel == 30 )
  {
    *analogVoltage = (((double)bytesVoltage)/65536.0)*4.88 - 4.88/2;
  }  
  else if(negChannel == 31)
  {
    *analogVoltage = (((double)bytesVoltage)/65536.0)*2.44;
  }
  //else if(negChannel == 31)  
  //{
  //  *analogVoltage = caliInfo->ainDiffSlope*((short)(bytesVoltage - 0x8000)) + caliInfo->ainDiffOffset + caliInfo->vref;
  //}
  else
  {
    sprintf( lastError, "Error: binaryToCalibratedAnalogVoltage(...) invalid negative channel %d.\n", negChannel );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }

  return 0;
} //  binaryToUncalibratedAnalogVoltage(...)



long    u3Base::analogToUncalibratedBinaryVoltage( double analogVoltage, uint8 *bytesVoltage )
{
/*  Translates a voltage value to binary analog input bytes (uncalibrated) 
    that can be sent to a u3.  Returns -1 on error, 0 on success. */

  double tempBytesVoltage;
  
  tempBytesVoltage = (analogVoltage/4.95)*256;
  
  //Checking to make sure bytesVoltage will be a value between 0 and 255, 
  //Too high of an analogVoltage (about 4.95 and above volts) or too low 
  //(below 0 volts) will cause a value not between 0 and 255.
  if(tempBytesVoltage < 0)
    tempBytesVoltage = 0;
  if(tempBytesVoltage > 255)  
    tempBytesVoltage = 255;
  
  *bytesVoltage = (uint8)tempBytesVoltage;

  return 0;
} //  analogToUncalibratedBinaryVoltage(...)



void    u3Base::buildInputCommandStart( void )
{
  int n;

  getCalibrationInfo();  

  sendBuff[0] = 9;              // ( used as receive byte counter during command build )
  sendBuff[1] = (uint8) 0xF8;  //Command byte
  sendBuff[2] = 1;              //Number of data words ( used as data byte counter during build )
  sendBuff[3] = (uint8) 0x00;  //Extended command number
  sendBuff[4] = 0;
  sendBuff[5] = 0;
  //------------------
  sendBuff[6] = 7;    //Echo  ( Used as index during buildInputCommand )

  //
  //  Clear confTable
  //
  for( n=0; n<(U3IOALEN+1); n++ ) {
    confTable[n].typeAD      = ' ';
    confTable[n].rBuffPos    = 0;
    confTable[n].u3Pos[0]    = 0;
    confTable[n].negCh       = 31;
    confTable[n].logState    = 0;
    confTable[n].voltage     = 0;
    confTable[n].calibrat    = 1;
    confTable[n].limitLow    = 0;
    confTable[n].limitHigh   = 0;
    confTable[n].remarks[0]  = 0;
  }
  confTable[U3IOALEN].typeAD = 0;
} //  buildInputCommandStart(...)



int     u3Base::buildInputCommandAIN( const char  *sFECio,
                                      int         nch,
                                      double      calibrat,   //  deviation from 2.44V (default 1.0)
                                      double      limitLow,
                                      double      limitHigh,
                                      const char  *remarks    //  Limited to 30 characters
                                    )
{
  char   pch;

  if( (pch = FECioToNum( sFECio )) < 0 ) {
    sprintf( lastError, "Error: buildInputCommandAIN(...) invalid u3 channel (%s). Must be something like \"FIO3\"\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( strcmp( sFECio, cnt0 ) == 0 ) {
    sprintf( lastError, "Error: buildInputCommandAIN(...) invalid u3 channel (%s). Channel used by counter0\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( strcmp( sFECio, cnt1 ) == 0 ) {
    sprintf( lastError, "Error: buildInputCommandAIN(...) invalid u3 channel (%s). Channel used by counter1\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  confTable[(int) confTable[U3IOALEN].typeAD].typeAD    = (char) 'A';
  confTable[(int) confTable[U3IOALEN].typeAD].rBuffPos  = (uint8) sendBuff[0];
  strcpy( confTable[(int) confTable[U3IOALEN].typeAD].u3Pos, sFECio );
  confTable[(int) confTable[U3IOALEN].typeAD].negCh     = (uint8) nch;
  confTable[(int) confTable[U3IOALEN].typeAD].calibrat  = calibrat;
  confTable[(int) confTable[U3IOALEN].typeAD].limitLow  = limitLow;
  confTable[(int) confTable[U3IOALEN].typeAD].limitHigh = limitHigh;
  strcpy( confTable[(int) confTable[U3IOALEN].typeAD].remarks, remarks );
  confTable[(int) confTable[U3IOALEN].typeAD].anaConLen = 0;
  confTable[(int) confTable[U3IOALEN].typeAD].hysteresis= 0;
  confTable[(int) confTable[U3IOALEN].typeAD].logState  = -2; //  Set undefined input state
  confTable[(int) confTable[U3IOALEN].typeAD].offDelay  = 0;
  confTable[(int) confTable[U3IOALEN].typeAD].onDelay   = 0;
  confTable[(int) confTable[U3IOALEN].typeAD].offRemain = 0;
  confTable[(int) confTable[U3IOALEN].typeAD].onRemain  = 0;
  confTable[U3IOALEN].typeAD++;

  sendBuff[sendBuff[6]++] = 1;    //IOType is AIN  (FIO0..FIO7)
  sendBuff[sendBuff[6]++] = pch;  //Positive channel (bits 0-4) is 0, LongSettling (bit 6) is not set
                                  //and QuickSample (bit 7) is not set
  sendBuff[sendBuff[6]++] = (uint8) nch;  //Negative channel is 31 (SE)
  sendBuff[2] += (uint8) 3;               //Adjust number of data bytes in send command
  sendBuff[0] += (uint8) 2;               //Adjust number of data bytes in receive command

  return  0;
} //  buildInputCommandAIN(...) Full version



int     u3Base::buildInputCommandAIN( const char  *sFECio,
                                      double      calibrat,   //  deviation from 2.44V (default 1.0)
                                      double      limitLow,
                                      double      limitHigh,
                                      const char  *remarks    //  Limited to 30 characters
                                    )
{
  return  buildInputCommandAIN( sFECio, 31, calibrat, limitLow, limitHigh, remarks );
} //  buildInputCommandAIN(...) Simple version



int     u3Base::buildInputCommandHYS( const char  *sFECio,    //  FIO0..7, FIOT, EIO0..7
                                      double      hysteresis  //  Hysteresis for changing logState
                                    )
{
  int n;
  
  if( (n = getConfTableNum(sFECio)) < 0 ) {
    sprintf( lastError, "Error: buildInputCommandHYS( %s, ... ). Channel not defined.\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  confTable[n].hysteresis = hysteresis;
  return  0;
} //  buildInputCommandHYS(...)



int     u3Base::buildInputCommandANC( const char    *sFECio,
                                      structAnaCon  *anaCon,  //  Conversion table
                                      int           anaConLen //  Size of table
                                    )
{
  int n;
  
  if( (n = getConfTableNum(sFECio)) < 0 ) {
    sprintf( lastError, "Error: buildInputCommandANC( %s, ... ). Channel not defined.\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  confTable[n].anaCon   = anaCon;
  confTable[n].anaConLen= anaConLen;
  return  0;
} //  buildInputCommandANC(...)



double  u3Base::vOutputAnaCon(  int     inputNumber,  //  Index in confTable
                                double  vInput )      //  Input value from an analog u3 channel
{
  int     x;
  double  factor, intervalIn, intervalOut;
  for( x=confTable[inputNumber].anaConLen-1; x>=0; x-- ) {
    if( vInput >= confTable[inputNumber].anaCon[x].vInput ) {
      if( x < (confTable[inputNumber].anaConLen-1) ) {
        //
        //  Find interpolation between (x) and (x+1)
        //
        //factor in between on input side
        intervalIn = confTable[inputNumber].anaCon[x+1].vInput-confTable[inputNumber].anaCon[x].vInput;
        factor = (vInput-confTable[inputNumber].anaCon[x].vInput) / intervalIn;
        intervalOut = confTable[inputNumber].anaCon[x+1].vOutput-confTable[inputNumber].anaCon[x].vOutput;
        return  confTable[inputNumber].anaCon[x].vOutput + intervalOut * factor;
      }
      return  confTable[inputNumber].anaCon[x].vOutput;
    }
  }
  return  confTable[inputNumber].anaCon[0].vOutput;
} //  vOutputAnaCon(...)



int     u3Base::buildInputCommandDIN( const char *sFECio,
                                      const char *remarks
                                    )
{
  int ch;

  if( (ch = FECioToNum( sFECio )) < 0 ) {
    sprintf( lastError, "Error: buildInputCommandDIN(...) Invalid u3 channel (%s). Must be something like \"FIO3\"\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( strcmp( sFECio, cnt0 ) == 0 ) {
    sprintf( lastError, "Error: buildInputCommandDIN(...) invalid u3 channel (%s). Channel used by counter0\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( strcmp( sFECio, cnt1 ) == 0 ) {
    sprintf( lastError, "Error: buildInputCommandDIN(...) invalid u3 channel (%s). Channel used by counter1\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  confTable[(int) confTable[U3IOALEN].typeAD].typeAD    = 'D';
  confTable[(int) confTable[U3IOALEN].typeAD].rBuffPos  = sendBuff[0];
  strcpy( confTable[(int) confTable[U3IOALEN].typeAD].u3Pos, sFECio );
  strcpy( confTable[(int) confTable[U3IOALEN].typeAD].remarks, remarks );
  confTable[(int) confTable[U3IOALEN].typeAD].logState  = -2; //  Set undefined input state
  confTable[(int) confTable[U3IOALEN].typeAD].offDelay  = 0;
  confTable[(int) confTable[U3IOALEN].typeAD].onDelay   = 0;
  confTable[(int) confTable[U3IOALEN].typeAD].offRemain = 0;
  confTable[(int) confTable[U3IOALEN].typeAD].onRemain  = 0;
  confTable[U3IOALEN].typeAD++;

  sendBuff[sendBuff[6]++] = 10;   //IOType is BitStateRead
  sendBuff[sendBuff[6]++] = ch;   //IO number is 11 (EIO3)
  sendBuff[2] += 2;               //Adjust number of data bytes in send command
  sendBuff[0] += 1;               //Adjust number of data bytes in receive command
  return  0;
} //  buildInputCommandDIN(...)



int     u3Base::buildInputCommandCIN( const char  *sFECio,    //  FIO0..7, EIO0..1
                                      int         cntNum,     //  0=counter0 1=counter1
                                      unsigned long cntLimit, //  Set logState at this point
                                      const char  *remarks )  //  Limited to 256 characters
{
  int ch;

  if( (ch = FECioToNum( sFECio )) < 0 ) {
    sprintf( lastError, "Error: buildInputCommandDIN(...) Invalid u3 channel (%s). Must be something like \"FIO3\"\n", sFECio );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  confTable[(int) confTable[U3IOALEN].typeAD].typeAD    = 'C';
  confTable[(int) confTable[U3IOALEN].typeAD].rBuffPos  = sendBuff[0];
  confTable[(int) confTable[U3IOALEN].typeAD].cntLimit  = cntLimit;
  strcpy( confTable[(int) confTable[U3IOALEN].typeAD].u3Pos, sFECio );
  strcpy( confTable[(int) confTable[U3IOALEN].typeAD].remarks, remarks );
  confTable[U3IOALEN].typeAD++;

  sendBuff[sendBuff[6]++] = (uint8) (54+cntNum);  //IOType is counter0 or 1
  sendBuff[sendBuff[6]++] = 0;          //Reset counter
  sendBuff[2] += 2;                     //Adjust number of data bytes in send command
  sendBuff[0] += 4;                     //Adjust number of data bytes in receive command


  //
  //  Also set timerconfig to debaounce mode (mode 6)
  //  We should be able to do it right not
  //
  //------------------
  sendBuff2[0] = 0;
  sendBuff2[1] = (uint8)(0xF8);  //Command byte
  sendBuff2[2] = 3;
  sendBuff2[3] = (uint8)(0x00);  //Extended command number
  sendBuff2[4] = 0;
  sendBuff2[5] = 0;
  //------------------
  sendBuff2[6] = 0;   //  Echo  

  sendBuff2[7] = 43;  //  IOType timer0
  sendBuff2[8] = 6;   //  Timer mode 6 (debounce 30msec)
  sendBuff2[9] = 30;  //  LSB value 30*30msec bounce time
  sendBuff2[10]= 0;   //  MSB value
  //------------------
  //Sending command to U3
  if( sendCommandU3( sendBuff2, 12 ) != 0 ) {
    sprintf( lastError, "Error sendCommandU3: set timer mode\n" );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: set timer mode\n" );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }

  return  0;
} //  buildInputCommandCIN(...)



void    u3Base::buildInputCommandEnd( void )
{
  confTabEnd = confTable[U3IOALEN].typeAD;
  recLength   = ((sendBuff[0]+1) >> 1) << 1;  //Return number of bytes to receive
  sendLength  = ((sendBuff[6]+1) >> 1) << 1;  //Return number of bytes to send
  sendBuff[0] = 0;
  sendBuff[2] = (sendBuff[2]+1) >> 1; //Number of data words
  sendBuff[6] = 0;                    //Echo
} //  buildInputCommandEnd()



int     u3Base::getNumConfTable( void )
{
  return  confTabEnd;
} //  getNumConfTable()



int     u3Base::checkAllInputs( void )
{
  int     n;
  double  voltage;
  unsigned long    ltemp0, ltemp1, ltemp2, ltemp3;

  //Sending command to U3
  if( sendCommandU3( sendBuff, sendLength ) != 0 ) {
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff, recLength ) != 0 ) {
    return -1;
  }

  for( n=0; n<confTabEnd; n++ ) {
    if( confTable[n].typeAD == 'A' ) {
      if( U3DEBUG == 1 ) {
        printf( "A: confTable[%d].u3Pos = %s\n", n, confTable[n].u3Pos );
      }
      if( abs( (int) (confTable[n].calibrat * 10000) ) < 1 ) {
        confTable[n].calibrat = 1.0;
      }
      if( confTable[n].u3Pos[3] == 'T' ) {  //  Tempreture sensor
        binaryToCalibratedAnalogTemperature(  recBuff[confTable[n].rBuffPos] + recBuff[confTable[n].rBuffPos + 1]*256,
                                              &voltage );
        voltage = voltage - 273;
      } else if( hvVersion && FECioToNum( confTable[n].u3Pos ) >= 0 && FECioToNum( confTable[n].u3Pos ) <= 3 ) {
        binaryToCalibratedAnalogHvVoltage(  FECioToNum( confTable[n].u3Pos ),
                                          recBuff[confTable[n].rBuffPos] + recBuff[confTable[n].rBuffPos + 1]*256,
                                          &voltage );
      } else {
        binaryToCalibratedAnalogVoltage(  31,
                                          recBuff[confTable[n].rBuffPos] + recBuff[confTable[n].rBuffPos + 1]*256,
                                          &voltage );
      }
      //
      //  User calibration (display)
      //
      confTable[n].voltage = voltage * confTable[n].calibrat;
      //
      //  Eventually run through conversion table
      //
      if( confTable[n].anaConLen > 0 ) {
        confTable[n].voltage = vOutputAnaCon( n, confTable[n].voltage );
      }
      analogFilter( n );
      //
      //  Check and react on lower/upper limits
      //
      if( confTable[n].voltage < confTable[n].limitLow ) {
        //  ... Check for propagation delay timing
        if( confTable[n].logState >= -2 ) {
          if( confTable[n].logState == -1 ) {
            confTable[n].offRemain  = 0;  //  Reset timer
            confTable[n].onRemain   = 0;  //  Reset timer
            //  logState is the same as current input state
          }
          if( confTable[n].onDelay > 0 ) { //  Use timer
            if( confTable[n].onRemain == 0 ) { //  Set timer
              confTable[n].onRemain = confTable[n].onDelay + time( NULL );
              //  Wait period start
            } else {
              if(  time( NULL ) >= confTable[n].onRemain ) { //  Time has run out
                confTable[n].onRemain = 0;    //  Reset timer
                if( confTable[n].logState != -1 ) {
                  logicChange = 1;
                }
                //  Acknowledge new state
                confTable[n].logState = -1;
              } else {
                //  Wait a bit longer
              }
            }
          } else {
            //  No delay defined, so just acknowledge new logState
            if( confTable[n].logState != -1 ) {
              logicChange = 1;
            }
            confTable[n].logState = -1;
          }
        } else {
          //  The current relay state is not know (predefined as -2).
          //  So just acknowledge this state
          if( confTable[n].logState != -1 ) {
            logicChange = 1;
          }
          confTable[n].logState = -1;
        }
        //  ---
      } else if( confTable[n].voltage > confTable[n].limitHigh ) {
        //  ... Check for propagation delay timing
        if( confTable[n].logState >= -2 ) {
          if( confTable[n].logState == 1 ) {
            confTable[n].offRemain  = 0;  //  Reset timer
            confTable[n].onRemain   = 0;  //  Reset timer
            //  logState is the same as current input state
          }
          if( confTable[n].onDelay > 0 ) { //  Use timer
            if( confTable[n].onRemain == 0 ) { //  Set timer
              confTable[n].onRemain = confTable[n].onDelay + time( NULL );
              //  Wait period start
            } else {
              if(  time( NULL ) >= confTable[n].onRemain ) { //  Time has run out
                confTable[n].onRemain = 0;    //  Reset timer
                //  Acknowledge new state
                if( confTable[n].logState != 1 ) {
                  logicChange = 1;
                }
                confTable[n].logState = 1;
              } else {
                //  Wait a bit longer
              }
            }
          } else {
            //  No delay defined, so just acknowledge new logState
            if( confTable[n].logState != 1 ) {
              logicChange = 1;
            }
            confTable[n].logState = 1;
          }
        } else {
          //  The current relay state is not know (predefined as -2).
          //  So just acknowledge this state
          if( confTable[n].logState != 1 ) {
            logicChange = 1;
          }
          confTable[n].logState = 1;
        }
        //  ---
      } else {
        if( confTable[n].logState != 0 && confTable[n].hysteresis != 0.0 ) {
          if( confTable[n].logState == 1 ) {
            if( ( confTable[n].voltage + confTable[n].hysteresis ) < confTable[n].limitHigh ) {
              //  ... Check for propagation delay timing
              if( confTable[n].logState >= -2 ) {
                if( confTable[n].logState == 0 ) {
                  confTable[n].offRemain  = 0;  //  Reset timer
                  confTable[n].onRemain   = 0;  //  Reset timer
                  //  logState is the same as current input state
                }
                if( confTable[n].offDelay > 0 ) { //  Use timer
                  if( confTable[n].offRemain == 0 ) { //  Set timer
                    confTable[n].offRemain = confTable[n].offDelay + time( NULL );
                    //  Wait period start
                  } else {
                    if(  time( NULL ) >= confTable[n].offRemain ) { //  Time has run out
                      confTable[n].offRemain = 0;    //  Reset timer
                      if( confTable[n].logState != 0 ) {
                        logicChange = 1;
                      }
                      //  Acknowledge new state
                      confTable[n].logState = 0;
                    } else {
                      //  Wait a bit longer
                    }
                  }
                } else {
                  //  No delay defined, so just acknowledge new logState
                  if( confTable[n].logState != 0 ) {
                    logicChange = 1;
                  }
                  confTable[n].logState = 0;
                }
              } else {
                //  The current relay state is not know (predefined as -2).
                //  So just acknowledge this state
                if( confTable[n].logState != 0 ) {
                  logicChange = 1;
                }
                confTable[n].logState = 0;
              }
              //  ---
            }
          } else {
            if( ( confTable[n].voltage - confTable[n].hysteresis ) > confTable[n].limitLow ) {
              //  ... Check for propagation delay timing
              if( confTable[n].logState >= -2 ) {
                if( confTable[n].logState == 0 ) {
                  confTable[n].offRemain  = 0;  //  Reset timer
                  confTable[n].onRemain   = 0;  //  Reset timer
                  //  logState is the same as current input state
                }
                if( confTable[n].offDelay > 0 ) { //  Use timer
                  if( confTable[n].offRemain == 0 ) { //  Set timer
                    confTable[n].offRemain = confTable[n].offDelay + time( NULL );
                    //  Wait period start
                  } else {
                    if(  time( NULL ) >= confTable[n].offRemain ) { //  Time has run out
                      confTable[n].offRemain = 0;    //  Reset timer
                      if( confTable[n].logState != 0 ) {
                        logicChange = 1;
                      }
                      //  Acknowledge new state
                      confTable[n].logState = 0;
                    } else {
                      //  Wait a bit longer
                    }
                  }
                } else {
                  //  No delay defined, so just acknowledge new logState
                  if( confTable[n].logState != 0 ) {
                    logicChange = 1;
                  }
                  confTable[n].logState = 0;
                }
              } else {
                //  The current relay state is not know (predefined as -2).
                //  So just acknowledge this state
                if( confTable[n].logState != 0 ) {
                  logicChange = 1;
                }
                confTable[n].logState = 0;
              }
              //  ---
            }
          } 
        } else {
          //  ... Check for propagation delay timing
          if( confTable[n].logState >= -2 ) {
            if( confTable[n].logState == 0 ) {
              confTable[n].offRemain  = 0;  //  Reset timer
              confTable[n].onRemain   = 0;  //  Reset timer
              //  logState is the same as current input state
            }
            if( confTable[n].offDelay > 0 ) { //  Use timer
              if( confTable[n].offRemain == 0 ) { //  Set timer
                confTable[n].offRemain = confTable[n].offDelay + time( NULL );
                //  Wait period start
              } else {
                if(  time( NULL ) >= confTable[n].offRemain ) { //  Time has run out
                  confTable[n].offRemain = 0;    //  Reset timer
                  if( confTable[n].logState != 0 ) {
                    logicChange = 1;
                  }
                  //  Acknowledge new state
                  confTable[n].logState = 0;
                } else {
                  //  Wait a bit longer
                }
              }
            } else {
              //  No delay defined, so just acknowledge new logState
              if( confTable[n].logState != 0 ) {
                logicChange = 1;
              }
              confTable[n].logState = 0;
            }
          } else {
            //  The current relay state is not know (predefined as -2).
            //  So just acknowledge this state
            if( confTable[n].logState != 0 ) {
              logicChange = 1;
            }
            confTable[n].logState = 0;
          }
          //  ---
        }
      }
    } else {
      if( confTable[n].typeAD == 'D' ) {
        if( U3DEBUG == 1 ) {
          printf( "D: confTable[%d].u3Pos = %s\n", n, confTable[n].u3Pos );
        }
        if( FECioToNum( confTable[n].u3Pos ) < 8 ) {
          //  ... Check for propagation delay timing
          if( confTable[n].logState > -2 ) {
            if( confTable[n].logState == recBuff[confTable[n].rBuffPos] ) {
              confTable[n].offRemain  = 0;  //  Reset timer
              confTable[n].onRemain   = 0;  //  Reset timer
              //  logState is the same as current input state
            }
            if( recBuff[confTable[n].rBuffPos] == 0 ) {  //  hi --> lo
              if( confTable[n].offDelay > 0 ) { //  Use timer
                if( confTable[n].offRemain == 0 ) { //  Set timer
                  confTable[n].offRemain = confTable[n].offDelay + time( NULL );
                  //  Wait period start
                } else {
                  if(  time( NULL ) >= confTable[n].offRemain ) { //  Time has run out
                    confTable[n].offRemain = 0;   //  Reset timer
                    if( confTable[n].logState != recBuff[confTable[n].rBuffPos] ) {
                      logicChange = 1;
                    }
                    //  Acknowledge new state
                    confTable[n].logState = recBuff[confTable[n].rBuffPos];
                  } else {
                    //  Wait a bit longer
                  }
                }
              } else {
                //  No delay defined, so just acknowledge new logState
                if( confTable[n].logState != recBuff[confTable[n].rBuffPos] ) {
                  logicChange = 1;
                }
                confTable[n].logState = recBuff[confTable[n].rBuffPos];
              }
            } else {  //  lo --> hi
              if( confTable[n].onDelay > 0 ) { //  Use timer
                if( confTable[n].onRemain == 0 ) { //  Set timer
                  confTable[n].onRemain = confTable[n].onDelay + time( NULL );
                  //  Wait period start
                } else {
                  if(  time( NULL ) >= confTable[n].onRemain ) { //  Time has run out
                    confTable[n].onRemain = 0;    //  Reset timer
                    //  Acknowledge new state
                    if( confTable[n].logState != recBuff[confTable[n].rBuffPos] ) {
                      logicChange = 1;
                    }
                    confTable[n].logState = recBuff[confTable[n].rBuffPos];
                  } else {
                    //  Wait a bit longer
                  }
                }
              } else {
                //  No delay defined, so just acknowledge new logState
                if( confTable[n].logState != recBuff[confTable[n].rBuffPos] ) {
                  logicChange = 1;
                }
                confTable[n].logState = recBuff[confTable[n].rBuffPos];
              }
            }
          } else {
            //  The current relay state is not know (predefined as -2).
            //  So just acknowledge this state
            if( confTable[n].logState != recBuff[confTable[n].rBuffPos] ) {
              logicChange = 1;
            }
            confTable[n].logState = recBuff[confTable[n].rBuffPos];
          }
          //  ---
        } else {  //  Pos >= 8 thus negated logic
          //  ... Check for propagation delay timing
          if( confTable[n].logState > -2 ) {
            if( confTable[n].logState == !recBuff[confTable[n].rBuffPos] ) {
              confTable[n].offRemain  = 0;  //  Reset timer
              confTable[n].onRemain   = 0;  //  Reset timer
              //  logState is the same as current input state
            }
            if( !recBuff[confTable[n].rBuffPos] == 0 ) {  //  hi --> lo
              if( confTable[n].offDelay > 0 ) { //  Use timer
                if( confTable[n].offRemain == 0 ) { //  Set timer
                  confTable[n].offRemain = confTable[n].offDelay + time( NULL );
                  //  Wait period start
                } else {
                  if(  time( NULL ) >= confTable[n].offRemain ) { //  Time has run out
                    confTable[n].offRemain = 0;   //  Reset timer
                    //  Acknowledge new state
                    if( confTable[n].logState != !recBuff[confTable[n].rBuffPos] ) {
                      logicChange = 1;
                    }
                    confTable[n].logState = !recBuff[confTable[n].rBuffPos];
                  } else {
                    //  Wait a bit longer
                  }
                }
              } else {
                //  No delay defined, so just acknowledge new logState
                if( confTable[n].logState != !recBuff[confTable[n].rBuffPos] ) {
                  logicChange = 1;
                }
                confTable[n].logState = !recBuff[confTable[n].rBuffPos];
              }
            } else {  //  lo --> hi
              if( confTable[n].onDelay > 0 ) { //  Use timer
                if( confTable[n].onRemain == 0 ) { //  Set timer
                  confTable[n].onRemain = confTable[n].onDelay + time( NULL );
                  //  Wait period start
                } else {
                  if(  time( NULL ) >= confTable[n].onRemain ) { //  Time has run out
                    confTable[n].onRemain = 0;    //  Reset timer
                    //  Acknowledge new state
                    if( confTable[n].logState != !recBuff[confTable[n].rBuffPos] ) {
                      logicChange = 1;
                    }
                    confTable[n].logState = !recBuff[confTable[n].rBuffPos];
                  } else {
                    //  Wait a bit longer
                  }
                }
              } else {
                //  No delay defined, so just acknowledge new logState
                if( confTable[n].logState != !recBuff[confTable[n].rBuffPos] ) {
                  logicChange = 1;
                }
                confTable[n].logState = !recBuff[confTable[n].rBuffPos];
              }
            }
          } else {
            //  The current relay state is not know (predefined as -2).
            //  So just acknowledge this state
            if( confTable[n].logState != !recBuff[confTable[n].rBuffPos] ) {
              logicChange = 1;
            }
            confTable[n].logState = !recBuff[confTable[n].rBuffPos];
          }
          //  ---
        }
      } else {
        if( confTable[n].typeAD == 'C' ) {
          if( U3DEBUG == 1 ) {
            printf( "C: confTable[%d].u3Pos = %s\n", n, confTable[n].u3Pos );
          }
          ltemp0 = recBuff[confTable[n].rBuffPos+0];
          ltemp1 = recBuff[confTable[n].rBuffPos+1];
          ltemp2 = recBuff[confTable[n].rBuffPos+2];
          ltemp3 = 0;
          ltemp1 *= 256;
          ltemp2 *= 256*256;
          ltemp3 *= 256*256*256;
          confTable[n].counter =  ltemp0 + ltemp1 + ltemp2 + ltemp3;
          if( confTable[n].counter >= confTable[n].cntLimit ) {
            if( confTable[n].logState != 1 ) {
              logicChange = 1;
            }
            confTable[n].logState = 1;
          } else {
            if( confTable[n].logState != 0 ) {
              logicChange = 1;
            }
            confTable[n].logState = 0;
          }
        } else {
          sprintf( lastError, "Error: confTable[%d].u3Pos = %s\n", n, confTable[n].u3Pos );
          if( PRINT_ERRORS ) {
            printf( "%s", lastError );
          }
          return  -1;
        }
      }
    }
  } //  for(...)

  //
  //  Copy all SSW from shared memory
  //
  if( shmid > 0 ) {
    for( n = 0; n < 10; n++ ) {
      if( ssw[n] != shareptr->ssw[n] ) {
        logicChange = 1;
      }
      ssw[n] = shareptr->ssw[n];
    }
  }

  if( logTabEnd > 0 ) {
    if( logTableCheck() != 0 ) {
      sprintf( lastError, "Error: in one or more logic equations faulty.\n" );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
      return  -1;
    }
  }

  //
  //  Move specific inputs and all relay states to shared memory
  //
  if( shmid > 0 ) {
    for( n = 0; n < getNumConfTable(); n++ ) {
      getConfTable( n,                        //  Input seequence
                    (structConfTable*) &shareptr->confTable[n].typeAD );//Shared memory to retrieve the lot
    }
    for( n = 0; n < U3IOALEN; n++ ) {
      getRelayOut(  n,                        //  Output number 0..19
                    (structRelayOut*) &shareptr->relayOut[n].logState );//Shared memory to retrieve the lot
    }
    shareptr->newDataAvailable = 1; //  Tell monitors that new data are available
  }

  return  0;
} //  checkAllInputs()



int     u3Base::setRelayComplex( const char* action ) //  This function can set/reset many relays in one go.
{                                                     //  The logic output channels have to be seperated by ' '.
  char  actions[64][16];                              //  A channel name preceeded by '!' will reset relay.  
  int   n, i, chan;                                   //  Loke: "EIO3 !EIO4" ==> EIO3 goes on and EIO4 goes off.
  char  *token, *ptoken;
  char  saction[1024];

  strcpy( saction, action );
  //
  //  Split the string action using ' ' as delimiter into actions[]
  //
  n = 0;
  token = strtok_r( saction, " ", &ptoken );
  if( strlen( token ) >= 4 ) {
    strcpy( actions[n], token );
    n++;
  }
  while( n<64 && (token = strtok_r( NULL, " ", &ptoken ) ) ) {
    if( strlen( token ) >= 4 ) {
      strcpy( actions[n], token );
      n++;
    }
  }

  //
  //  Do actions on actions[] strings
  //
  for( i=0; i<n; i++ ) {
    if( actions[i][0] == '!' ) {
      chan = FECioToNum( &actions[i][1] );
      if( chan != (-1) ) {
        setRelay( chan, 0 );
      } else {
        sprintf( lastError, "Error: Channel %s is not a valid channel\n", &actions[i][1] );
        if( PRINT_ERRORS ) {
          printf( "%s", lastError );
        }
      }
    } else {
      chan = FECioToNum( actions[i] );
      if( chan != (-1) ) {
        setRelay( chan, 1 );
      } else {
        sprintf( lastError, "Error: Channel %s is not a valid channel\n", actions[i] );
        if( PRINT_ERRORS ) {
          printf( "%s", lastError );
        }
      }
    }
  }
  return 0;
} //  setRelayComplex(...)



int     u3Base::logTableCheck(void )
{
  //
  //  Walk through all defined outputs and
  //  evaluate if the output is to be set high.
  //  Store new states until all evaluations are done.
  //  then set the new states.
  //
  //  The evaluation is done in the method logicTableEval( int nLogTab ).
  //
  int nLogTab;    //  Index logTab
  int nLogOut;    //  Logic digital out channel number
  int setTCommand[U3IOALEN];
  int setTState[U3IOALEN];
  int setTIndexMax;
  int setTIndex;
  int res;

  //
  //  Calculate new state and store them temporarily
  //
  res = 0;
  setTIndexMax = 0;
  for( nLogTab=0; nLogTab<logTabEnd; nLogTab++ ) {
    nLogOut = FECioToNum( logTab[nLogTab].lOutput );
    setTCommand[setTIndexMax] = nLogOut;
    setTState[setTIndexMax++] = logicTableEval( nLogTab );
  }

  //
  //  Execute the new states
  //
  for( setTIndex=0; setTIndex<setTIndexMax; setTIndex++ ) {
    if( setTCommand[setTIndex] == FECioToNum( "RCT0" ) ) {
      if( setTState[setTIndex] == 1 ) {
        res = res | resetCounter( 0 );
      }
    } else if( setTCommand[setTIndex] == FECioToNum( "RCT1" ) ) {
      if( setTState[setTIndex] == 1 ) {
        res = res | resetCounter( 1 );
      }
    } else {
      res = res | setRelay( setTCommand[setTIndex], setTState[setTIndex] );
    }
  }

  return  res;
} //  logTableCheck()



int     u3Base::logicTableEval( int nLogTab )
{
  //
  //  The input conditions line (logTab[nLogTab].lInput) might look like this to
  //  begin with: "!FIH3 * ( FIL3 + FIM3 ) * EIO3".
  //  Substutude all channel/analogLogic entries from logTab[nLogTab].lInput with
  //  "T" and "F" according to to respective inputs and their eventual negation to
  //  a string called sEval.
  //  The result in sEval could then look something like: "T*T*T" <== "T * ( F + T ) * T".
  //  Inthe above case, the equation would set nState to 1 (true).
  //  When evaluating sEval, the entries in brackets must be evauated first. The
  //  evaluation is done recursively until there are no operator left.
  //
  int   nState;   //  Return output state
  int   i, ii;
  char  sEval[1024],sEval1[1024],sEval2[1024],sEval3[1024];
  
  nState = 0;
  
  strcpy( sEval, logTab[nLogTab].lInput );
  while( strlen( sEval ) > 1 ) {
    //
    //  Check for '('
    //
    strcpy( sEval1, "" );
    strcpy( sEval2, "" );
    strcpy( sEval3, "" );
    //
    //  See if there are any '(' in sEval
    //
    for( i=0; i< (int) strlen( sEval ) && sEval[i] != '('; i++ );
    if( sEval[i] == '(' ) {
      if( i > 0 ) {
        //
        //  copy first part of sEval before '(' to sEval1
        //
        strncpy( sEval1, sEval, i );  //  should give: "!FIH3 * "
        sEval1[i] = '\0';
      }
      i++;
      //
      //  Find the terminating ')'
      //
      for( ii=i; ii< (int) strlen( sEval ) && sEval[ii] != ')'; ii++ );
      if( sEval[ii] != ')' ) {
        sprintf( lastError, "Error: logicTableEval(...) missing ')' in \"%s\" = \"%s\"\n",
                  logTab[nLogTab].lOutput, logTab[nLogTab].lInput );
        if( PRINT_ERRORS ) {
          printf( "%s", lastError );
        }
        return  -1;
      }
      if( (ii-i) >= 4 ) {
        //
        //  Copy the part within brackets from sEval to sEval2
        //
        strncpy( sEval2, &sEval[i], ii-i );   //  should give: " FIL3 + FIM3 "
        sEval2[ii-i] = '\0';
        if( logEval( sEval2 ) == -1 ) {       //  should give: "T" <== "F+T"
          return  -1;
        }
      } else {
        sprintf( lastError, "Error: logicTableEval(...) no expression within '( )' in \"%s\" = \"%s\"\n",
                  logTab[nLogTab].lOutput, logTab[nLogTab].lInput );
        if( PRINT_ERRORS ) {
          printf( "%s", lastError );
        }
        return  -1;
      }
      //
      //  Add the sEval2 to sEval1
      //
      strcat( sEval1, sEval2 );
      if( (ii+1) < (int) strlen( sEval ) ) {
        //
        //  Copy rest of sEval excluding the ')' to sEval3
        //
        strcpy( sEval3, &sEval[ii+1] );
      }
      //
      //  Add also sEval3 to sEval1
      //
      strcat( sEval1, sEval3 );
      //
      //  Copy the result in sEval1 to sEval
      //
      strcpy( sEval, sEval1 );
    } else {
      //
      //  No brackets left in string
      //  so do final logEval()
      //
      if( logEval( sEval ) == -1 ) {  //  should give: "T" <== "T*T*T" <== "!FIH3 * T * EIO3"
        return  -1;
      }
    }
  } //  while(...)

  if( sEval[0] == 'T' ) {
    return  1;
  } else {
    return  0;
  }
} //  logicTableEval(...)



int     u3Base::logEval( char *sEval )
{
  //
  //  We could have a string (sEval) like this: "!FIH3 * T * EIO3 + EIO04" and
  //  it has to be converted to: "T" or "F".
  //  So first split the string into an array called aEval[] using ' ' as delimiter.
  //  Then evaluate elements to T or F in aEval[] not consisting of * or +.
  //  Finally calculate tre resulting state (T/F) using first the * oprator, then the + operator.
  //
  /*
  typedef struct STRUCT_AEVAL {
    char    s[16];
  } structaEval;
  */

  char  aEval[64][16];
  char  sTemp;
  char  *token, *ptoken;
  int   n, n2, n3, nx, neg, state;

  n = 0;
  token = strtok_r( sEval, " ", &ptoken );
  if( strlen( token ) > 0 ) {
    strcpy( aEval[n], token );
    n++;
  }
  while( n<64 && (token = strtok_r( NULL, " ", &ptoken ) ) ) {
    if( strlen( token ) > 0 ) {
      strcpy( aEval[n], token );
      n++;
    }
  }

  //
  //  Now that we have the individual items in the aEval array
  //  we will evaluate each non-operand
  //
  for( n2=0; n2<n; n2++ ) {
    if( aEval[n2][0] != '*' && aEval[n2][0] != '+' ) {
      if( aEval[n2][0] == '!' ) {
        neg = 1;
        strcpy( aEval[n2], &aEval[n2][1] );
      } else {
        neg = 0;
      }
      if( strncmp( aEval[n2], "SSW", 3 ) == 0 ) { //  Search for logic software switch state
        if( ssw[FECioToNum( aEval[n2] )] ^ neg ) {
          strcpy( aEval[n2], "T" );
        } else {
          strcpy( aEval[n2], "F" );
        }
      } else
      if( strncmp( &aEval[n2][1], "IO", 2 ) == 0 ) { //  Search for logic digital input/output state
        if( getConfTableNum( aEval[n2] ) >= 0 &&
            ( getInputType( getConfTableNum( aEval[n2] ) ) == 'D' ||
              getInputType( getConfTableNum( aEval[n2] ) ) == 'C' ) ) {  //  This is a logic input
          if( getInputState( aEval[n2] ) ^ neg ) {
            strcpy( aEval[n2], "T" );
          } else {
            strcpy( aEval[n2], "F" );
          }
        } else {  //  Make sure it is a defined logic output
          if( getRelayState( aEval[n2] ) == -1 ) {
            sprintf( lastError, "Error: logEval getRelayState( aEval[%d] ) = %s\n", n2, aEval[n2] );
            if( PRINT_ERRORS ) {
              printf( "%s", lastError );
            }
            return  -1;
          }
          if( getRelayState( aEval[n2] )  ^ neg ) {
            strcpy( aEval[n2], "T" );
          } else {
            strcpy( aEval[n2], "F" );
          }
        }
      } else
      if( strncmp( &aEval[n2][1], "IL", 2 ) == 0 ) { //  Search for logic analog low input state
        aEval[n2][2] = 'O'; //  Change "FILn" to "FIOn" so we can use standard methods
        state = getInputState( aEval[n2] );
        if( state == (-1) ) {
          state = 1;
        } else {
          state = 0;
        }
        if( state ^ neg ) {
          strcpy( aEval[n2], "T" );
        } else {
          strcpy( aEval[n2], "F" );
        }
      } else
      if( strncmp( &aEval[n2][1], "IH", 2 ) == 0 ) { //  Search for logic analog high input state
        aEval[n2][2] = 'O'; //  Change "FIHn" to "FIOn" so we can use standard methods
        state = getInputState( aEval[n2] );
        if( state == 1 ) {
          state = 1;
        } else {
          state = 0;
        }
        if( state ^ neg ) {
          strcpy( aEval[n2], "T" );
        } else {
          strcpy( aEval[n2], "F" );
        }
      } else
      if( strncmp( &aEval[n2][1], "IM", 2 ) == 0 ) { //  Search for logic analog mid input state
        aEval[n2][2] = 'O'; //  Change "FIMn" to "FIOn" so we can use standard methods
        state = getInputState( aEval[n2] );
        if( state == 0 ) {
          state = 1;
        } else {
          state = 0;
        }
        if( state ^ neg ) {
          strcpy( aEval[n2], "T" );
        } else {
          strcpy( aEval[n2], "F" );
        }
      }
    }
  }

  //
  //  Last step is to calculate the equation of
  //  all the T*F+T*T etc.
  //  Multiplications in the boolean equation is done first and
  //  then the sums.
  //
  for( n2=0; (n2+2)<n; ) {   //  T*F+T*T
    if( aEval[n2+1][0] == '*' ) {   //  Multiply T*F ==> F
      if( aEval[n2+0][0] == 'T' && aEval[n2+2][0] == 'T' ) {
        sTemp = 'T';
      } else {
        sTemp = 'F';
      }
      n -= 2;
      for( n3=n2; n3<n; n3+=2 ) {
        aEval[n3+0][0] = aEval[n3+2][0];
        aEval[n3+1][0] = aEval[n3+3][0];
      }
      aEval[n2][0] = sTemp;
      for( nx=0; nx<n; nx++ ) {
      }
    } else {
      n2 += 2;
    }
  }
  for( n2=0; (n2+2)<n; ) {   //  T*F+T*T
    if( aEval[n2+1][0] == '+' ) {   //  Sums T+F ==> T
      if( aEval[n2+0][0] == 'T' || aEval[n2+2][0] == 'T' ) {
        sTemp = 'T';
      } else {
        sTemp = 'F';
      }
      n -= 2;
      for( n3=n2; n3<n; n3+=2 ) {
        aEval[n3+0][0] = aEval[n3+2][0];
        aEval[n3+1][0] = aEval[n3+3][0];
      }
      aEval[n2][0] = sTemp;
      for( nx=0; nx<n; nx++ ) {
      }
    } else {
      n2 += 2;
    }
  }

  strcpy( sEval, aEval[0] );

  if( n == 1 ) {
    return  0;
  } else {
    return -1;
  }
} //  logEval(...)



int     u3Base::logicTableAdd(const char  *sFECo,     //  FIO0..7, EIO0..7, CIO0..3 (Logic digital output)
                              const char  *sFECi)     //  FIL0..7, FILT, EIL0..7,   (logic analog Low input)
                                                      //  FIM0..7, FIMT, EIM0..7,   (logic analog Mid input)
                                                      //  FIH0..7, FIHT, EIH0..7,   (logic analog High input)
                                                      //  FIO0..7, EIO0..7, CIO0..7,(logic digtal input/output)
                                                      //  *, +, (, ), !             (logic operators)
                                                      //  max 1023 characters
{
  int n;

  if( strlen( sFECo ) != 4 ) {
    sprintf( lastError, "Error: logicTableAdd(...) sFECo (%s) must be 4 characters long.\n", sFECo );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return  -1;
  }
  if( strlen( sFECi ) >= 1024 ) {
    sprintf( lastError, "Error: logicTableAdd(...) sFECi (%s) must be less than 1024 characters long.\n", sFECi );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return  -1;
  }
  if( strlen( sFECi ) < 4 ) {
    sprintf( lastError, "Error: logicTableAdd(...) sFECi (%s) must consist of an least one input statement.\n", sFECi );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return  -1;
  }
  if( FECioToNum( sFECo ) == -1 ) {
    sprintf( lastError, "Error: logicTableAdd(...) sFECo (%s) does not exist.\n", sFECo );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return  -1;
  }
  for( n=0; n<logTabEnd; n++ ) {
    if( strcmp( logTab[n].lOutput, sFECo ) == 0 ) {
      sprintf( lastError,
        "Error: logicTableAdd(...) sFECo (%s) is already equated (output hazrd).\n       This equation is skipped.\n",
        sFECo );
      if( PRINT_ERRORS ) {
        printf( "%s", lastError );
      }
      return  -1;
    }
  }
  strcpy( logTab[logTabEnd].lOutput, sFECo );
  strcpy( logTab[logTabEnd++].lInput, sFECi );
  return  0;
} //  logicTableAdd(...)



char    u3Base::getInputType( int inputNumber )
{
  if( inputNumber >= 0 && inputNumber < U3IOALEN ) {
    return  confTable[inputNumber].typeAD;
  } else {
    sprintf( lastError, "Error: Input index out of range (%d)\n", inputNumber );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return  '?';
  }
} //  getInputType(...)



int     u3Base::setLED( int state )   //  LED on: state=1 off: state=0
{
  if( state != 0 ) {
    state = 1;
  }
  //------------------
  sendBuff2[0] = 0;
  sendBuff2[1] = (uint8)(0xF8);  //Command byte
  sendBuff2[2] = 2;
  sendBuff2[3] = (uint8)(0x00);  //Extended command number
  sendBuff2[4] = 0;
  sendBuff2[5] = 0;
  //------------------
  sendBuff2[6] = 0;    //Echo  

  sendBuff2[7] = 9;    //IOType is LED
  sendBuff2[8] = (uint8) state;   //  Set/reset LED
  //------------------
  //Sending command to U3
  if( sendCommandU3( sendBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error sendCommandU3: setLED( %d )\n", state );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: setLED( %d )\n", state );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  setLED(...)



int     u3Base::buzz( void )
{
  int continuously = 0; //  0 ~ not cont.
  int period = 70;      //  70 ~ 4KHz
  int toggles = 500;    //  500 ~ 500msec
  //------------------
  sendBuff2[0] = 0;
  sendBuff2[1] = (uint8)(0xF8);  //Command byte
  sendBuff2[2] = 4;
  sendBuff2[3] = (uint8)(0x00);  //Extended command number
  sendBuff2[4] = 0;
  sendBuff2[5] = 0;
  //------------------
  sendBuff2[6] = 0;    //Echo  

  sendBuff2[7] = 63;   //IOType is buzzer
  sendBuff2[8] = (uint8) continuously;          //  continuously
  sendBuff2[9] = (uint8) (period & 0xFF);       //  period LSB
  sendBuff2[10]= (uint8) ((period>>8) & 0xFF);  //  period MSB
  sendBuff2[11]= (uint8) (toggles & 0xFF);      //  toggles LSB
  sendBuff2[12]= (uint8) ((toggles>>8) & 0xFF); //  toggles MSB
  sendBuff2[13]= 0;
  //------------------
  //Sending command to U3
  if( sendCommandU3( sendBuff2, 14 ) != 0 ) {
    sprintf( lastError, "Error sendCommandU3: buzz( %d, %d, %d )\n", continuously, period, toggles );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: buzz( %d, %d, %d )\n", continuously, period, toggles );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  buzz(...)




int     u3Base::setDAC( int dacNumber, int value ) //  0..1, 0..255
{
  //------------------
  sendBuff2[0] = 0;
  sendBuff2[1] = (uint8)(0xF8);  //Command byte
  sendBuff2[2] = 2;
  sendBuff2[3] = (uint8)(0x00);  //Extended command number
  sendBuff2[4] = 0;
  sendBuff2[5] = 0;
  //------------------
  sendBuff2[6] = 0;    //Echo  

  if( dacNumber == 0 ) {
    sendBuff2[7] = 34;   //IOType DAC0
  } else
  if( dacNumber == 1 ) {
    sendBuff2[7] = 35;   //IOType DAC1
  } else {
    sprintf( lastError, "Error: setDAC(..): wrong channel number %d\n", dacNumber );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  sendBuff2[8] = (uint8) value;     //  continuously
  //------------------
  //Sending command to U3
  if( sendCommandU3( sendBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error sendCommandU3: setDAC( %d, %d )\n", dacNumber, value );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff2, 10 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: setDAC( %d, %d )\n", dacNumber, value );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  setDAC(...)



int     u3Base::setDAC( const char *sDAC, double value ) //  "DAC0".."DAC1", 0..2.44V
{
  uint8   iValue;

  if( analogToCalibratedBinaryVoltage( FECioToNum( sDAC ), value, &iValue ) != -1 ) {
    return  setDAC( FECioToNum( sDAC ), iValue );
  } else {
    return  -1;
  }
} //  setDAC(...)



int     u3Base::streamConfig( int numChannels,        //  
                              int samplesPerPacket,   //  1..16
                              int scanInterval )      //  1..65535  65535~33msec @ 2MHz
{
  int n, i;

  streamInfo.numChannels      = numChannels;
  streamInfo.samplesPerPacket = samplesPerPacket;
  streamInfo.scanInterval     = scanInterval;
  //------------------
  sendBuff2[0] = 0;
  sendBuff2[1] = (uint8)(0xF8);  //Command byte
  sendBuff2[2] = (uint8)(numChannels + 3);
  sendBuff2[3] = (uint8)(0x11);  //Extended command number
  sendBuff2[4] = 0;
  sendBuff2[5] = 0;
  sendBuff2[6] = (uint8) numChannels;
  sendBuff2[7] = (uint8) samplesPerPacket;
  sendBuff2[8] = 0;             //Reserved
                                //  76543210
  sendBuff2[9] = (uint8) binToInt( "00000000" );  //ScanConfig  2MHz
  sendBuff2[10]= (uint8) (scanInterval & 0xFF);
  sendBuff2[11]= (uint8) ((scanInterval >> 8) & 0xFF);
  //------------------
  //  Add the channels
  i = 0;
  for( n=0; n<(U3IOALEN); n++ ) {
    if( getInputType( n ) == 'A' ) {
      sendBuff2[12+i] = FECioToNum( confTable[n].u3Pos );
      sendBuff2[13+i] = (uint8) confTable[n].negCh;
      i += 2;
    }
  }
  //------------------
  //Sending command to U3
  if( sendCommandU3( sendBuff2, 12+i ) != 0 ) {
    sprintf( lastError, "Error sendCommandU3: streamConfig( %d, %d, %d )\n",
              numChannels, samplesPerPacket, scanInterval );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //Reading response from U3
  if( recCommandU3( recBuff2, 8 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: streamConfig( %d, %d, %d )\n",
              numChannels, samplesPerPacket, scanInterval );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  streamConfig(...)



int     u3Base::streamStart( void )
{
  int recChars;

  //------------------
  sendBuff2[0] = 0xA8;
  sendBuff2[1] = 0xA8;
  //------------------
  //Sending command to U3
  LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuff2, 2 );
  //Reading response from U3
  recChars = LJUSB_BulkRead(fd, U3_PIPE_EP2_IN, recBuff2, 4 );
  if( recChars != 4 ) {
    sprintf( lastError, "Error recCommandU3: streamStart() only received %d/4\n", recChars );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( recBuff2[2] != 0 ) {
    sprintf( lastError, "Error recCommandU3: streamStart() %d - %s\n", recBuff2[2], getErrorText( recBuff2[2] ) );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  streamStart(...)



int     u3Base::streamStop( void )
{
  int recChars;

  //------------------
  sendBuff2[0] = 0xB0;
  sendBuff2[1] = 0xB0;
  //------------------
  //Sending command to U3
  LJUSB_BulkWrite( fd, U3_PIPE_EP1_OUT, sendBuff2, 2 );
  //Reading response from U3
  recChars = LJUSB_BulkRead(fd, U3_PIPE_EP2_IN, recBuff2, 4 );
  if( recChars != 4 ) {
    sprintf( lastError, "Error recCommandU3: streamStop() only received %d/4\n", recChars );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( recBuff2[2] != 0 ) {
    sprintf( lastError, "Error recCommandU3: streamStop() %d - %s\n", recBuff2[2], getErrorText( recBuff2[2] ) );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  streamStop(...)



int     u3Base::streamData( void )
{
  int n, i;

  //------------------
  /*
  sendBuff2[0] = 0;             //  Checksum8
  sendBuff2[1] = (uint8)(0xF9); //Command byte
  sendBuff2[2] = (uint8)(streamInfo.samplesPerPacket + 4);
  sendBuff2[3] = (uint8)(0xC0); //Extended command number
  sendBuff2[4] = 0;             //  Checksum16 (LSB)
  sendBuff2[5] = 0;             //  Checksum16 (MSB)
  sendBuff2[6] = 0;             //  Timestamp (reserved)
  sendBuff2[7] = 0;             //  Timestamp (reserved)
  sendBuff2[8] = 0;             //  Timestamp (reserved)
  sendBuff2[9] = 0;             //  Timestamp (reserved)
  sendBuff2[10]= 0;             //  Packet counter
  sendBuff2[11]= 0;             //  Error code
  */
  //------------------
  //  Add the channels
  i = 0;
  for( n=0; n<(U3IOALEN); n++ ) {
    if( getInputType( n ) == 'A' ) {
      sendBuff2[12+i] = FECioToNum( confTable[n].u3Pos );
      sendBuff2[13+i] = (uint8) confTable[n].negCh;
      i += 2;
    }
  }
  //------------------
  //Reading response from U3
  if( recCommandU3( recBuff2, 8 ) != 0 ) {
    sprintf( lastError, "Error recCommandU3: streamData() packets=%d, ErrorCode=%d\n", sendBuff2[10], sendBuff2[11] );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  return 0;
} //  streamData(...)



int     u3Base::analogFilter( int confTableIndex )
{
  //
  //  u3Base::confTable[confTableIndex].voltage holds the newly retrieved value to be filetered
  //
  return  0;
}



int   u3Base::useSharedMemory( void )
{
  int n;

  shmid = shmget( (key_t) IPC_PRIVATE,          //  new, unused shared memory region is desired
                  sizeof( structSharemem ),     //  minimum size in bytes of the desired shared memory
                  PERMS | IPC_CREAT);           //  ID for the segment is to be created using the specified key
  if( shmid < 0 ) {
    sprintf( lastError, "Error: shared memory creation failed \n" );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  if( ( shareptr = (structSharemem *) shmat( shmid, 0, 0) ) == (structSharemem *) -1 ) {
    sprintf( lastError, "Error: cannot attach to shared memory\n" );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  //  Store the shmid in in file SHM_FILE_NAME for monitor programs to use.
  if( ( shmIDFile = fopen( SHM_FILE_NAME, "w" ) ) == NULL ) {
    sprintf( lastError, "Error: cannot write file %s for shared memory ID\n", SHM_FILE_NAME );
    if( PRINT_ERRORS ) {
      printf( "%s", lastError );
    }
    return -1;
  }
  sprintf( charTemp, "%d", shmid );
  fputs( charTemp, shmIDFile );
  fclose( shmIDFile );

  //
  //  Copy all software switches to shared memory
  //
  for( n = 0; n < 10; n++ ) {
    shareptr->ssw[n] = ssw[n];
  }

  return  0;
} //  useSharedMemory()



int     u3Base::getLogicChange()
{
  int lc;
  
  lc  = logicChange;
  logicChange = 0;
  return  lc;
} //  getLogicChange()



const char*   u3Base::getLastError( void )
{
  return  lastError;
} //  getLastError()
