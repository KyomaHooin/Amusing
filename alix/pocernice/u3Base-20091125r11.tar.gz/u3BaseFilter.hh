/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

        D E M O   C L A S S

 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



#include  "u3Base.hh"



class u3BaseFilter : public u3Base
{

  protected:
    //
    //  Special for analog filter
    //
    double            vOld[U3IOALEN+1];
    int               vOldFirst[U3IOALEN+1];
    int               timeConst[U3IOALEN+1];

  public:
    friend class u3Base;

                        //  Constructor
            u3BaseFilter(     int devicePath );   //  If devicePath is 0 then U3_DEVICE_PATH is used.

                        //  Destructor
    virtual ~u3BaseFilter(    void );

                        //  Filter is diabled for all analog inputs by default (0), but can be enabled per
                        //  individually by setting a time constant value to a positive value larger than 1.
                        //  By setting the timeConst to 1200, the time constant for the filter will be 1 minute
                        //  assuming a sample rate of 20 msec. (60sec/20msec*22=
    int     setTimeConst(     const char  *sFECio,    //  FIO0..7, FIOT, EIO0..7
                              int         timeConst );//  0...any positive value

  protected:
                        //  Filter method: Integration over 1200 samples for 90% of target value
                        //  All analog inputs are filtered.
                        //  Assuming 20msec sampling rate, the filter time constant is 1min
    virtual int analogFilter( int confTableIndex ); //  u3Base::confTable[confTableIndex].voltage
                                                    //  holds the newly retrieved value to be filetered
                                                    //  Actions on value is first taken after this filter.
                                                    //  In u3Base this method doesn't affect the value.

};
