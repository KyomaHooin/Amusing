/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

        D E M O   P R O G R A M

        Using additional filter class (u3BaseFilter.cc and .hh)

ljrun is a program for the U3 device to register temperature and control
the oil burner amongst other things.
It is tailored to my house "Nybygget" near Ljungby in Sweden.

Uses u3Base class for C++ (g++) Linux

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

In a Make file you you could have the folling text:

-----------------------
SRC=ljrun.cc u3Base.cc u3BaseFilter.cc saveterm.cc termbar.cc
OBJ=$(SRC:.c=.o .cc=.o)

SRCS=$(wildcard *.c *.cc)
HDRS=$(wildcard *.h *.hh)

CFLAGS=-Wall -g
CC=g++ $(CFLAGS)
LIBS=-lm -llabjackusb

all: ljrun

ljrun: $(OBJ)
	$(CC) -o ljrun $(OBJ) $(LIBS)

clean: 
	rm -f *.o ljrun
----------------------

You can run it by typing:
$ ./ljrun --config

in a terminal

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



//
//  ================ Includes ================
//

#include  <errno.h>  
#include  <stdio.h>
#include  "u3Base.hh"
#include  "u3BaseFilter.hh"
#include  "saveterm.hh"
#include  "termbar.hh"



//
//  ================ Defines ================
//



//
//  ================ Forward declarations ================
//

void  printHelpMessage( char *argv );
int   setupU3wr( u3BaseFilter  *u3b );
int   setupU3( u3BaseFilter  *u3b );
int   setup( u3BaseFilter  *u3b );
const char* getErrMsg( int errnum );



//
//  ================ Application manin ================
//

int   main( int argc, char **argv )
{
  long  count;
  int   n;
  structConfTable table;  //  Varibale to hold retrieved with u3Base::getConfTable(...)
  structRelayOut  rtable; //  Varibale to hold retrieved with u3Base::getRelayOut(...)
  termbar tb;             //  A horizontal bar class showing semi graphic value
  div_t dcount;
  char  sTemp[255];



  //
  //  Now to the program seequence
  //
  if( argc > 1 && strcmp( argv[1], "--help" ) == 0 ) {
    printHelpMessage( argv[0] );
    return  1;
  }

  //  ---------------------------------------------------------------------------------  //
  //  Please note that not the base class, but rather it's extended version is called.   //
  //  The addition af the filter class is a good skelleton to your own filter.           //
  //  See the files u3BaseFilter.hh and u3BaseFilter.cc for details.                     //
  //  ---------------------------------------------------------------------------------  //
  u3BaseFilter  u3b( 1 );      //  Construct the class to interface to U3 number 1
  // printf( "ConnectID = %d ... ", u3b.getConnecID() );
  printf( "ConnectID = %d (assumed) ... ", 1 );
  if( u3b.getConnecID() == NULL ) {
    printf( "failed\n" );
    return  11;
  }
  printf( "success\n" );

  if( argc > 1 && strcmp( argv[1], "--wrconfig" ) == 0 ) {
    setupU3wr( &u3b );
    printf( "Recycle the power to the U3 for configuration to take effect\n" );
    return  2;
  }
  if( argc > 1 && strcmp( argv[1], "--config" ) == 0 ) {
    setupU3( &u3b );
    printf( "configured\n" );
  }

  //
  //  Initialize shared memory for eventual monor programs to use.
  //  Other programs can look for the file SHM_FILE_NAME in order to
  //  get shmid and thus attach to this shared memory. See u3Base.hh
  //
  u3b.useSharedMemory();

  saveterm st;  //  Construct class to save current terminal and implement kbhit() method
                //  The destructor takes care of restoring the original terminal values.

  if( ( n = setup( &u3b ) ) != 0 ) {  //  Build all interface
    return  4;  //  One or more command errors
  }

  //
  //  Show preset of SSW (SoftwareSWitches)
  //
  for( n = 0; n < 10; n++ ) {
    sprintf( sTemp, "SSW%d", n );
    printf( "SSW%d: %d\n", n, u3b.getSSW( sTemp ) );
  }

  //  -------- Run timed loop --------

  //
  //  This main loop consists of two parts:
  //    The outer loop of 100mSec, which is to be the sampling rate.
  //    A sub devision of 20 (2sec) that provides for printing to the terminal.
  //  Execution time for a sample is not taken into consideration, but is
  //  relative short on an over 2GHz computer.
  //
  count = 0;
  while( !st.kbhit() )
  {
    count++;
    
    u3b.setDAC( "DAC0", (count & 0xFF) * 2.44 / 0xFF );
                              //  Kind of silly, but this makes kind of a ramp,
                              //  thus the output voltage increases with the
                              //  loop count'er and then a suddent fall to 0.
                              //  If you connect it to an analog input, then
                              //  you can follow the event.

    //
    //  Sample inputs
    //
    u3b.checkAllInputs();
    

    dcount = div( count, 100 );
    if( dcount.rem == 0 ) { //  Only print every 100th time (2 sec)
      //
      //  Print input values/states - Method 1
      //
      if( u3b.getLogicChange() ) {
        printf( "Sample = %ld - Change\n", count );
      } else {
        printf( "Sample = %ld\n", count );
      }
      for( n=0; n<u3b.getNumConfTable(); n++ ) {
        u3b.getConfTable( n,        //  0..19, 31 Input
                          &table ); //  User variable to retrieve the lot
        switch( table.typeAD ) {
          case 'A':
            if( strcmp( table.u3Pos, "FIO6" ) == 0 ) {
              printf( "%6.2f %s %s - %d\n",
                      table.voltage, table.remarks, tb.bar( table.voltage,  10,  40, 20 ), table.logState );
            } else if( strcmp( table.u3Pos, "FIOT" ) == 0 ) {
              printf( "%6.2f %s %s - %d\n",
                      table.voltage, table.remarks, tb.bar( table.voltage,  20,  28, 20 ), table.logState );
            } else if( strcmp( table.u3Pos, "FIO5" ) == 0 ) {
              printf( "%6.2f %s %s - %d\n",
                      table.voltage, table.remarks, tb.bar( table.voltage,  20,  28, 20 ), table.logState );
            } else if( strcmp( table.u3Pos, "FIO0" ) == 0 ) {
              printf( "%6.2f %s %s - %d\n",
                      table.voltage, table.remarks, tb.bar( table.voltage, 9.0, 9.6, 20 ), table.logState  );
            } else {
              printf( "%6.2f %s\n", table.voltage, table.remarks );
            }
            break;
          case 'D':
            printf( "%4d %s\n", table.logState, table.remarks );
            break;
          case 'C':
            printf( "%4d %6d %s\n", table.logState, (int)table.counter, table.remarks );
            break;
        }
      }

      //
      //  Print relay states
      //
      printf( "\n" );
      printf( "%4d %s\n", u3b.getRelayState( "EIO0" ), u3b.getRelayText( "EIO0" ) );
      printf( "%4d %s\n", u3b.getRelayState( "EIO1" ), u3b.getRelayText( "EIO1" ) );
      printf( "%4d %s\n", u3b.getRelayState( "EIO2" ), u3b.getRelayText( "EIO2" ) );
      printf( "%4d %s\n", u3b.getRelayState( "EIO3" ), u3b.getRelayText( "EIO3" ) );
      u3b.getRelayOut( "EIO4", &rtable );
      printf( "%4d %s\n", rtable.logState, rtable.logState ? rtable.onText : rtable.offText );
      printf( "  -------------------------\n\n\n" );

      //
      //  Audio that battery is OK
      //  Just an example.
      //
      /*
      if( u3b.getInputState( "FIO0" ) == 0 ) u3b.buzz();
      */

      //
      //  toggle LED as watch-dog.
      //  This might be a very bad idea for permanent use as a mechanical relay is involved.
      //
      /*
      u3b.setLED( count & u3b.binToInt( "0100" ) );
      */
    }

    //
    //  Wait 10msec before doing the next sample
    //  It appears that 20ms is the resolution for the test computer's usleep(...)
    //
    usleep( 20 * 1000 ); //  1/50 sec

  } //  while(...) loop

  printf( "\n" );
  st.~saveterm();

  return 0; //  Restore original terminal settings
} //  main(...)



//
//  ================ Sub functions ================
//



int   setupU3wr( u3BaseFilter  *u3b )
{
  u3b->writeConf( "01110111",     //  FIOAnalog 1=Analog 0=logic
                  "00000000",     //  EIOAnalog 1=Analog 0=logic
                                  //  CIOx is always logic
                  "00000000",     //  DirFIO 1=output 0=input
                  "11111111",     //  DirEIO 1=output 0=input
                      "0000",     //  DirCIO 1=output 0=input
                  "00001000",     //  StateFIO 1=hi 0=lo
                  "00000000",     //  StateEIO 1=hi 0=lo
                      "0000",     //  StateCIO 1=hi 0=lo
                  "FIO7",         //  Counter0
                  "" );           //  Counter1
  return  0;
} //  setupU3wr(...)



int   setupU3( u3BaseFilter  *u3b )
{
  u3b->writeConf( "01110111",     //  FIOAnalog 1=Analog 0=logic
                  "00000000",     //  EIOAnalog 1=Analog 0=logic
                                  //  CIOx is always logic
                  "00000000",     //  DirFIO 1=output 0=input
                  "11111111",     //  DirEIO 1=output 0=input
                      "0000",     //  DirCIO 1=output 0=input
                  "FIO7",         //  Counter0
                  "" );           //  Counter1
  return  0;
} //  setupU3(...)



int   setup( u3BaseFilter  *u3b )
{
  //
  //  Table for conversion of silicium diode voltage to degrees Celcius.
  //  This is not calibrated at all, but gives a good idea of how to use
  //  the analog conversion table.
  //  Resistor 6K8 from VREF to input and diode from input to GND.
  //  A silicium diode drops 2mV/degree or close to this value.
  //  If one measure the voltage @20 degree to 0.66V then the value @100
  //  and @-40 degree can be calculated:
  //  @100 = 0.66 - (100-20)*0.002 = 0.50V
  //  @-40 = 0.66 + (20-(-40))*0.002 = 0.78V
  //  With a 12bit converter, as used in U3, the resolution is:
  //  2.44V / 2^12 = 0.0006V ~ 0.0006 / 0.002 = 0.3 degrees
  //  Table is static so it will not "disappear" after leaving setup(...)
  //
  /*
  static  structAnaCon  anaConSDiode[] =
  {
    { 0.66 - ((100)-( 20))*0.002, 100.0 },
    { 0.66 + (( 20)-(-40))*0.002, -40.0 }
  };
  */

  //
  //  Table for conversion of germanium diode voltage to degrees Celcius
  //  This is not calibrated at all, but gives a good idea of how to use
  //  the analog conversion table.
  //  Resistor 6K8 from VREF to input and diode from input to GND.
  //  A germanium diode drops about 3mV/degree as far as I remember.
  //  The diode used is an OC91 from the time of the Flintstones.
  //  @100 = 0.29 - ( 60-( 20))*0.003
  //  @-40 = 0.29 + ( 20-(-20))*0.003
  //  With a 12bit converter, as used in U3, the resolution is:
  //  2.44V / 2^12 = 0.0006V ~ 0.0006 / 0.003 = 0.2 degrees (not too bad)
  //  Table is static so it will not "disappear" after leaving setup(...)
  //
  static  structAnaCon  anaConGDiode4[] = //  Inside
  {
    { 0.2944-(( 60)-( 20))*0.002,  60.0 },
    { 0.2944+(( 20)-(-20))*0.002, -20.0 }
  };
  static  structAnaCon  anaConGDiode5[] = //  Outside
  {
    { 0.284-(( 60)-( 20))*0.002,  60.0 },
    { 0.284+(( 20)-(-20))*0.002, -20.0 }
  };

  //  -------- Needed instructions Input --------

  u3b->buildInputCommandStart();
                            // inp    cali   min  max    remarks
  u3b->buildInputCommandAIN(  "FIO0", 4.00,  9.0, 9.6,  "V  FIO0 9.0-9.6V DC - 9V batt. test" );  //0
  u3b->buildInputCommandDelay("FIO0", 2, 0 );   //  OK > 2s:  !mid==>mid=2s  mid==>!mid=0s
  u3b->setTimeConst(          "FIO0", 60*20 );                 // Set a 1min filter

  u3b->buildInputCommandAIN(  "FIO2", 1.00,  0.0, 2.5,  "V  FIO2 0-2.44V DC" ); //1

  u3b->buildInputCommandAIN(  "FIO4", 1.00,  0.0, 0.0,  "C  FIO4 Internal temperature" ); //2
  u3b->buildInputCommandANC(  "FIO4", &anaConGDiode4[0], 2 ); // See table towards the top of setup(...)
  u3b->buildInputCommandHYS(  "FIO4", 2.0 );                  // Hysteresis for logState 2.0 degrees
  u3b->setTimeConst(          "FIO4", 60*20 );                // Set a 1min filter

  u3b->buildInputCommandAIN(  "FIO5", 1.00,  0.0,10.0,  "C  FIO5 External temperature" ); //3
  u3b->buildInputCommandANC(  "FIO5", &anaConGDiode5[0], 2 );  // See table towards the top of setup(...)
  u3b->buildInputCommandHYS(  "FIO5", 2.0 );                   // Hysteresis for logState 2.0 degrees
  u3b->buildInputCommandDelay("FIO5",60,60 );   //  OK > 2s:  !mid==>mid=60s  mid==>!mid=60s
  u3b->setTimeConst(          "FIO5", 60*20 );                 // Set a 1min filter

  u3b->buildInputCommandAIN(  "FIO6", 1000,   10,  40,  "mV FIO6 Analog input 10-40mVDC Heat EIO3" ); //4
  u3b->setTimeConst(          "FIO6", 600*20 );                // Set a 10min filter

  u3b->buildInputCommandAIN(  "FIOT", 1.00,   18,  29,  "C  FIOT Internal tempreture (ambient)    " );  //5

                            // inp     remarks
  u3b->buildInputCommandDIN(  "CIO0", "CIO0 input from mechanical switch for CNT0" ); //6
  u3b->buildInputCommandDIN(  "CIO2", "CIO2 input oil burner running" );  //7

                            // inp    # max   remarks
  u3b->buildInputCommandCIN(  "FIO7", 0,  6, "Count 6 things on FIO7 using CNT0" ); //8

  u3b->buildInputCommandDIN(  "FIO3", "FIO3 Supplement heating needed" );  //9

  u3b->buildInputCommandEnd();

  printf( "build inputs\n" );

  //  -------- Instructions for logic outputs --------

                  // outp    OFF state remarks                 ON state remarks
  u3b->setRelayText( "EIO0", "EIO0 relay OFF - 24V power OK",  "EIO0 relay ON  - 24V power fail" );
  u3b->setRelayText( "EIO1", "EIO1 9V battery is fine.",       "EIO1 9V batt. < 9.0V or > 9.6V" );
  u3b->setRelayText( "EIO2", "EIO2 Oil burner disabled",       "EIO2 Oil burner enabled" );
  u3b->setRelayText( "EIO3", "EIO3 heater OFF",                "EIO3 heater ON" );
  u3b->setRelayText( "EIO4", "EIO4 Package filling",           "EIO4 Package filled with items (throw 1sec)" );
  u3b->setRelayText( "EIO5", "EIO5 relay OFF",                 "EIO5 relay ON" );
  u3b->setRelayText( "EIO6", "EIO6 relay OFF",                 "EIO6 relay ON" );
  u3b->setRelayText( "EIO7", "EIO7 relay OFF",                 "EIO7 relay ON" );

                  // outp   off on
  u3b->setRelayDelay("EIO0", 30, 0 );   //  Make sure power is ok for at least 30 seconds
  u3b->setRelayDelay("EIO3", 30,30 );   //  30 seconds reaction time for heating
  u3b->setRelayDelay("EIO4",  4, 0 );   //  Four second one-shut needed to throw filled package

  printf( "build outputs\n" );

  //  -------- Instructions for logic decissions --------

  u3b->setSSW( "SSW0" );
  u3b->setSSW( "SSW1" );
  u3b->setSSW( "SSW2" );
  u3b->setSSW( "SSW3" );

  u3b->logicTableAdd( "EIO0", "!CIO0 * SSW0" );   //  Start emergency power when power failure
  u3b->logicTableAdd( "EIO1", "!FIM0 * SSW1" );   //  Battery is either under or over voltage
  u3b->logicTableAdd( "EIO2", "EIO2 * SSW2 + FIO3 + SSW4" );           //  Enable/Disable oil burner
  u3b->logicTableAdd( "EIO3", "FIL6 * SSW3"  );   //  Start heater when too cold

  //u3b->logicTableAdd( "EIO4", "FIO7"  );        //  Package filled with items <== Counter0 >= 6
  //u3b->logicTableAdd( "FIO3", "CIO0"  );        //  Counter0 <== FIO7 <== FIO3 <== CIO0 <== Switch
  //u3b->logicTableAdd( "RCT0", "EIO4"  );        //  Reset counter0 if relay CIO0 has sent 4 sec signal

  printf( "build logic\n" );

  //  -------- Relay presets --------

  u3b->setRelayComplex( "!FIO3 !EIO0 !EIO1 !EIO2 !EIO3 !EIO4 !EIO5 !EIO6 !EIO7" );
  u3b->resetCounter( 0 );

  printf( "performed logic presets\n" );

  return  0;
} //  setup(...)



void    printHelpMessage( char *argv )
{
    printf( "\n" \
            "Interface to Labjack U3-USB for Linux\n" \
            "By Carl Friis-Hansen GPL 2006 - http://carl-fh.net/u3/\n" \
            "\n" \
            "Usage:\n" \
            "  %s                              (use default programmed configuration)\n" \
            "  %s --help                       (this help message)\n" \
            "  %s --wrconfig                   (write default config to U3 EEPROM)\n" \
            "  %s --config                     (configure U3)\n" \
            "  %s --cfile <configuration file> (use external config. See u3Conf.pdf)\n" \
            "\n" \
            "Return codes:\n" \
            "  0: Normal termination\n" \
            "  1: --help option given\n" \
            "  2: Default configuration of U3-USB device was updated in EEPROM\n" \
            "  11: Error connecting to U3-USB device\n" \
            "\n" \
            , argv, argv, argv, argv, argv );
} //  printHelpMessage(...)



const char* getErrMsg( int errnum )
{
    switch ( errnum ) {

#ifdef EACCES
        case EACCES :
        {
            return "EACCES Permission denied";
        }
#endif

#ifdef EPERM
        case EPERM :
        {
            return "EPERM Not super-user";
        }
#endif

#ifdef E2BIG
        case E2BIG :
        {
            return "E2BIG Arg list too long";
        }
#endif

#ifdef ENOEXEC
        case ENOEXEC :
        {
            return "ENOEXEC Exec format error";
        }
#endif

#ifdef EFAULT
        case EFAULT :
        {
            return "EFAULT Bad address";
        }
#endif

#ifdef ENAMETOOLONG
        case ENAMETOOLONG :
        {
            return "ENAMETOOLONG path name is too long     ";
        }
#endif

#ifdef ENOENT
        case ENOENT :
        {
            return "ENOENT No such file or directory";
        }
#endif

#ifdef ENOMEM
        case ENOMEM :
        {
            return "ENOMEM Not enough core";
        }
#endif

#ifdef ENOTDIR
        case ENOTDIR :
        {
            return "ENOTDIR Not a directory";
        }
#endif

#ifdef ELOOP
        case ELOOP :
        {
            return "ELOOP Too many symbolic links";
        }
#endif

#ifdef ETXTBSY
        case ETXTBSY :
        {
            return "ETXTBSY Text file busy";
        }
#endif

#ifdef EIO
        case EIO :
        {
            return "EIO I/O error";
        }
#endif

#ifdef ENFILE
        case ENFILE :
        {
            return "ENFILE Too many open files in system";
        }
#endif

#ifdef EINVAL
        case EINVAL :
        {
            return "EINVAL Invalid argument";
        }
#endif

#ifdef EISDIR
        case EISDIR :
        {
            return "EISDIR Is a directory";
        }
#endif

#ifdef ELIBBAD
        case ELIBBAD :
        {
            return "ELIBBAD Accessing a corrupted shared lib";
        }
#endif
  }
  return "Unknown error";
} //  getErrMsg(...)
