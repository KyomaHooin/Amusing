/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

        D E M O   P R O G R A M

hello

Test of u3Base class for C++ (g++) Linux

Started by Carl Friis-Hansen 2006 (carl.friis-hansen@carl-fh.com).
This software is with GPL (use it as you feel like).

Although most methods has a return code, 0=OK -1=fail, I have chosen not
to use these for the sake of clarity in this very simple hello program.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

In order to to compile it you need this file plus u3Base.hh and u3Base.cc.
plus svaveterm.hh and saveterm.cc
In a Make file you you could have the folling text:

-----------------------
SRC=hello.cc u3Base.cc saveterm.cc
OBJ=$(SRC:.c=.o .cc=.o)

SRCS=$(wildcard *.c *.cc)
HDRS=$(wildcard *.h *.hh)

CFLAGS=-Wall -g
CC=g++ $(CFLAGS)
LIBS=-lm -llabjackusb

all: hello

hello: $(OBJ)
	$(CC) -o hello $(OBJ) $(LIBS)

clean: 
	rm -f *.o hello
----------------------



* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



//
//  ================ Includes ================
//

#include  <stdio.h>
#include  "saveterm.hh"
#include  "u3Base.hh"



//
//  ================ Application manin ================
//

int   main()
{
  long  count;
  div_t dcount;

  //
  //  Now to the program seequence
  //

  u3Base  u3b( 1 );      //  Construct the class to interface to U3

  if( u3b.getConnecID() <= 0 ) {
    printf( "Error: connection to U3 failed (is driver installed and hardware turned on?)\n" );
    return  1;
  }

  u3b.writeConf(  "01110111",     //  FIOAnalog 1=Analog 0=logic
                  "00000000",     //  EIOAnalog 1=Analog 0=logic
                                  //  CIOx is always logic
                  "00001000",     //  DirFIO 1=output 0=input
                  "11111111",     //  DirEIO 1=output 0=input
                      "0000",     //  DirCIO 1=output 0=input
                  "00000000",     //  StateFIO
                  "00000000",     //  StateEIO
                      "0000",     //  StateCIO
                  "",             //  Counter0
                  "" );           //  Counter1

  u3b.buildInputCommandStart();
                            // inp    cali   min  max    remarks
  u3b.buildInputCommandAIN(  "FIO1", 1.00,  0.0, 0.0,  "  FIO1 0-2.44V DC" );
  u3b.buildInputCommandEnd();


  saveterm st;  //  Construct class to save current terminal and implement kbhit() method
                //  The destructor takes care of restoring the original terminal values.

  printf( "\n" );
  printf( "Running 20msec loop with print out to terminal every 2sec\n" );
  printf( "Press 'q' or any other key to stop.\n" );
  printf( "\n" );

  //  -------- Run timed loop --------

  //
  //  This main loop consists of two parts:
  //    The outer loop of 100mSec, which is to be the sampling rate.
  //    A sub devision of 20 (2sec) that provides for printing to the terminal.
  //  Execution time for a sample is not taken into consideration, but is
  //  relative short on a 2GHz computer or better.
  //
  count = 0;
  while( !st.kbhit() )
  {
    count++;
    
    //
    //  Sample inputs, execute logic equations, set outputs etc.
    //
    u3b.checkAllInputs();
    
    dcount = div( count, 100 );
    if( dcount.rem == 0 ) { //  Only print every 100th time (2 sec)
      //
      //  Print input value
      //
      printf( "Sample = %ld - %6.2fV %s\n", count, u3b.getInputVoltage("FIO1"), u3b.getInputText("FIO1") );
    }

    //
    //  Wait 10msec before doing the next sample
    //  It appears that 20ms is the resolution for the test computer's usleep(...)
    //
    usleep( 20 * 1000 ); //  1/50 sec

  } //  while(...) loop

  printf( "Ending the hello program in an orderly fashion\n" );

  return 0;
} //  main(...)
